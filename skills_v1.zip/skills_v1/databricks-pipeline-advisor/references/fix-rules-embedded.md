# Fix Rules — Embedded (Complete Standalone Copy)
# Version: 2026-04-01
# Used when datastage-notebook-standardizer skill is not installed.
# Contains the full content of fix-rules.md + stage-patterns.md + expression-map.md.
# Keep in sync with the standardizer's reference files whenever those are updated.
# SYNC CHECK: version line above must match datastage-notebook-standardizer/references/fix-rules.md

---

# ════════════════════════════════════════════════════
# PART 1 — FIX RULES
# ════════════════════════════════════════════════════

## NEVER TOUCH — read before applying any rule

These patterns must NEVER be modified regardless of which group fires:

| Pattern | Why |
|---|---|
| IF() inside F.expr("...") or expr("...") | Valid Spark SQL — not DataStage BASIC — **EXCEPTION: the null+empty guard pattern `IF(col IS NOT NULL And trim(col) <> '', <expr>, NULL) as ALIAS` IS converted by Group G rule G-NULL-GUARD** |
| IF() inside spark.sql("...") body | Valid Spark SQL — Group Q handles syntax only |
| <> inside spark.sql("...") body | Valid ANSI SQL |
| String literals 'Y', 'N', 'true', 'false' in any branch | Never convert to boolean/integer |
| Any error code string '5005', '5006', '5016' etc. | Business values — never change |
| .alias("name") before a join | Intentional column disambiguation |
| toPandas() / collect() | Add # REVIEW: may OOM on large data only |
| CTEs (WITH ... AS), window functions, 4+ table JOINs | Keep spark.sql(), fix refs + syntax only |
| Traceability block comments | Preserve on every cell including cache cells |
| DataFrame variable names | Never rename — lnkChanges stays lnkChanges |

---

## GROUP G — DataStage Syntax in Python Context

**Applies ONLY when the pattern appears as a bare Python call — outside any string.**

Detection scope:
- `.withColumn("col", IF(...))` — bare Python call → fix
- `.filter(col <> '')` — bare Python → fix
- `.withColumn("col", F.expr("IF(...)"))` — inside expr() → DO NOT touch
- `.withColumn("col", expr("IF(...)"))` — inside expr() → DO NOT touch
- `spark.sql("... IF(...) ...")` — inside SQL string → DO NOT touch (Group Q handles)

| DataStage | PySpark | Confidence |
|---|---|---|
| IF(c, t, f) bare Python | F.when(c, t).otherwise(f) | AUTO |
| IF cond THEN t ELSE f bare Python | F.when(cond, t).otherwise(f) | AUTO |
| Trim(col) | F.trim(F.col("col")) | AUTO |
| Strip(col,"leading") | F.ltrim(F.col("col")) | AUTO |
| Strip(col,"trailing") | F.rtrim(F.col("col")) | AUTO |
| LTrim(col) | F.ltrim(F.col("col")) | AUTO |
| RTrim(col) | F.rtrim(F.col("col")) | AUTO |
| Upcase(col) | F.upper(F.col("col")) | AUTO |
| Downcase(col) | F.lower(F.col("col")) | AUTO |
| Left(col, n) | F.col("col").substr(1, n) | AUTO |
| Right(col, n) | F.expr(f"right(col, {n})") | AUTO |
| Mid(col, s, n) | F.col("col").substr(s, n) | AUTO |
| Length(col) bare Python | F.length(F.col("col")) | AUTO |
| Len(col) | F.length(F.col("col")) | AUTO |
| Str(col, n) | F.lpad(F.col("col"), n, " ") | AUTO |
| Not(expr) | ~(expr) | AUTO |
| IsNull(col) bare Python | F.col("col").isNull() | AUTO |
| IsNotNull(col) bare Python | F.col("col").isNotNull() | AUTO |
| NVL(col, val) bare Python | F.coalesce(F.col("col"), F.lit(val)) | AUTO |
| NullToEmpty(col) | F.coalesce(F.col("col"), F.lit("")) | AUTO |
| NullToZero(col) | F.coalesce(F.col("col"), F.lit(0)) | AUTO |
| Index(col, s, n) | F.locate(s, F.col("col"), n) | AUTO |
| Convert(c, from, to) | F.regexp_replace(F.col("c"), from, to) | AUTO |
| DateToString(c, fmt) | F.date_format(F.col("c"), fmt) | AUTO |
| StringToDate(c, fmt) | F.to_date(F.col("c"), fmt) | AUTO |
| StringToTimestamp(c, fmt) | F.to_timestamp(F.col("c"), fmt) | AUTO |
| StringToInteger(col) | F.col("col").cast("integer") | AUTO |
| StringToDecimal(col) | F.col("col").cast("double") | AUTO |
| IntToString(col) | F.col("col").cast("string") | AUTO |
| DecimalToString(col) | F.col("col").cast("string") | AUTO |
| Age(col) / DaysSince(col) | F.datediff(F.current_date(), F.col("col")) | AUTO |
| Int(col) | F.col("col").cast("long") | AUTO |
| Abs(col) | F.abs(F.col("col")) | AUTO |
| Round(col, n) | F.round(F.col("col"), n) | AUTO |
| Mod(a, b) | F.col("a") % F.col("b") | AUTO |
| Num(col) | F.col("col").cast("double") | AUTO |
| Sqrt(col) | F.sqrt(F.col("col")) | AUTO |
| LJustify(col, n) | F.rpad(F.col("col"), n, " ") | AUTO |
| RJustify(col, n) | F.lpad(F.col("col"), n, " ") | AUTO |
| Squote(col) | F.concat(F.lit("'"), F.col("col"), F.lit("'")) | AUTO |
| Dquote(col) | F.concat(F.lit('"'), F.col("col"), F.lit('"')) | AUTO |
| Today() | F.current_date() | AUTO |
| Now() | F.current_timestamp() | AUTO |
| TimeStampToDate(col) | F.to_date(F.col("col")) | AUTO |
| SecondsToTime(col) | F.from_unixtime(F.col("col")) | AUTO |
| <> in Python .filter() or .withColumn() | != | AUTO |
| \|\| string concat in Python context | F.concat(F.col("a"), F.col("b")) | AUTO |
| col1 : col2 (DataStage colon concat) | F.concat(F.col("col1"), F.col("col2")) | AUTO |
| @NULL bare Python | F.lit(None) | AUTO |
| @TRUE bare Python | F.lit(True) | AUTO |
| @FALSE bare Python | F.lit(False) | AUTO |
| @INROWNUM | row_number() over partition window — see PART 2 TRANSFORMER section | REVIEW |
| @NUMROWS | count("*") over partition window — see PART 2 TRANSFORMER section | REVIEW |
| @OUTROWNUM | row_number() over global order window — see PART 2 TRANSFORMER section | REVIEW |

**When converting IF(c, t, f) to F.when(c, t).otherwise(f):**
- Preserve t and f values EXACTLY — 'Y' → F.lit('Y'), 'N' → F.lit('N')
- Never convert string literals to boolean or integer equivalents
- If t or f is a string literal → wrap with F.lit("value") explicitly

```python
# CORRECT — literal values preserved
.withColumn("REJECTRECORD", F.when(F.col("SIEBELACCTIDERR1") != "", F.lit("Y")).otherwise(F.lit("N")))

# WRONG — never do this
.withColumn("REJECTRECORD", F.when(F.col("SIEBELACCTIDERR1") != "", 1).otherwise(0))
```

### G-NULL-GUARD — F.expr null-and-empty guard pattern (AUTO · MEDIUM)

Lakebridge generates a DataStage boilerplate pattern: a null+empty check wrapped in SQL
`IF()` inside `F.expr()` or `expr()`. Convert the outer guard to native PySpark.
Preserve the inner value expression exactly by re-wrapping it in `F.expr("""...""")`.

**Detect these patterns (case-insensitive AND/And, both `<>` and `!=` match):**
```python
F.expr("""IF ( col IS NOT NULL And trim(col) <> '' , <value_expr> , NULL ) as ALIAS""")
expr("""IF ( col IS NOT NULL And trim(col) <> '' , <value_expr> , NULL ) as ALIAS""")
```

**Convert to:**
```python
F.when(
    F.col("col").isNotNull() & (F.trim(F.col("col")) != ""),
    F.expr("""<value_expr>""")
).otherwise(None).alias("ALIAS")
```

**Conversion rules:**
- `col IS NOT NULL And trim(col) <> ''` → `F.col("col").isNotNull() & (F.trim(F.col("col")) != "")`
- The inner `<value_expr>` is re-wrapped in `F.expr("""...""")` triple-quotes unchanged — do NOT rewrite it
- `NULL` in the else branch → `.otherwise(None)`
- `as ALIAS` suffix → `.alias("ALIAS")`
- Applies to both `F.expr()` and bare `expr()` — scan all cells

```python
# BEFORE
F.expr("""IF ( DealCorEffectiveDate IS NOT NULL And trim(DealCorEffectiveDate) <> '' ,
    to_timestamp(concat( date_format(current_timestamp,'yyyymmdd') , ' ' , '00:00:00' )) ,
    NULL ) as DLR_CORE_EFF_DTE"""),

# AFTER
F.when(
    F.col("DealCorEffectiveDate").isNotNull() & (F.trim(F.col("DealCorEffectiveDate")) != ""),
    F.expr("""to_timestamp(concat( date_format(current_timestamp,'yyyymmdd') , ' ' , '00:00:00' ))""")
).otherwise(None).alias("DLR_CORE_EFF_DTE"),
```

**Do NOT apply when:**
- The `IF()` condition tests anything other than `col IS NOT NULL And trim(col) <> ''`
  (e.g. CDC flag, error code, business condition) → leave it as `F.expr()` / `expr()`
- The expression is inside a `spark.sql("...")` body → Group Q handles that context

---

## GROUP Q — DataStage Syntax in SQL Context

Applies ONLY inside spark.sql("...") string bodies.

**Q-HARD — ABSOLUTE RULE, no exceptions:**
NEVER rewrite, summarize, simplify, or restructure the body of a spark.sql() call.
Copy the SQL body VERBATIM. The ONLY permitted change is replacing hardcoded table
name strings with f-string variable references (e.g. `ENR_HIER` → `{source_table}`).
Fabricating table references, dropping columns, changing WHERE conditions, collapsing
subqueries, or reformatting JOINs are all CRITICAL violations that produce runtime errors.

**Q-SOURCES — scan ALL nesting levels for table references:**
When parameterizing table names, scan every FROM and JOIN clause at ALL levels —
including inside inline subqueries, CTEs, and nested FROM clauses. Every distinct
table found must be added as a separate source_table parameter. A table inside a
subquery is just as real as a table in the outer FROM. Missing a subquery table =
CRITICAL violation (hardcoded name left in SQL).

**Q-VERIFY — cross-check SELECT columns after fixing:**
After fixing a spark.sql() SOURCE cell, verify every column in its SELECT list
exists by checking the NEXT cell that consumes the DataFrame. If the downstream cell
references df.COLUMN_NAME, that column MUST be present in the SELECT. Missing columns
= CRITICAL runtime error. Flag any discrepancy as REVIEW before outputting.

| DataStage | Spark SQL fix | Confidence |
|---|---|---|
| IF(c, t, f) inside SQL | CASE WHEN c THEN t ELSE f END | AUTO |
| IF cond THEN t ELSE f inside SQL | CASE WHEN c THEN t ELSE f END | AUTO |
| IsNull(col) inside SQL | col IS NULL | AUTO |
| IsNotNull(col) inside SQL | col IS NOT NULL | AUTO |
| NVL(col, val) capital N inside SQL | coalesce(col, val) | AUTO |
| <> inside SQL | KEEP — valid ANSI SQL | — |
| trim(), upper(), lower() inside SQL | KEEP — valid Spark SQL | — |

**When to keep spark.sql() vs convert to DataFrame API:**

| SQL Content | Action |
|---|---|
| Single-table SELECT + WHERE (no JOIN, no GROUP BY, no aggregation) | Convert to DataFrame API |
| Any JOIN present | Keep spark.sql() — fix refs and syntax only |
| Any GROUP BY present | Keep spark.sql() — fix refs and syntax only |
| Any aggregation function present | Keep spark.sql() — fix refs and syntax only |
| CTEs (WITH ... AS) | Keep spark.sql() — fix refs and syntax only |
| Window functions (OVER PARTITION BY) | Keep spark.sql() — fix refs and syntax only |
| Subqueries (inline or correlated) | Keep spark.sql() — fix refs and syntax only |
| UNION / UNION ALL | Keep spark.sql() — fix refs and syntax only |

**Default rule: when in doubt, keep spark.sql(). Only convert when 100% safe.**

**SQL fixes (apply when keeping spark.sql()):**

| Pattern | Fix | Confidence |
|---|---|---|
| GROUP BY 1,2 positional | Replace with actual column names | AUTO |
| SELECT * with known schema | Keep as-is — schema enforcement is Delta's job | — |

---

## GROUP R — Source / Target Conversion

**Rule: every source read → Delta. No exceptions.**

| Original | Fixed |
|---|---|
| spark.read.csv(path) | spark.read.format("delta").table(source_table) |
| spark.read.parquet(path) | spark.read.format("delta").table(source_table) |
| spark.read.json(path) | spark.read.format("delta").table(source_table) |
| spark.read.format("jdbc").load() | spark.read.format("delta").table(source_table) |
| spark.read.format("oracle")... | spark.read.format("delta").table(source_table) |
| Any spark.read not format("delta") | spark.read.format("delta").table(source_table) |
| df.write.csv/parquet/json(path) | df.write.format("delta").saveAsTable(target_table) |

All confidence: AUTO. For multiple sources use source_table1, source_table2 etc.

---

## GROUP N — Naming Standards + Teradata Placeholder Replacement

**Variable naming — absolute rule:**
- Single source: source_table · Single target: target_table
- Multiple: source_table1, source_table2 · target_table1, target_table2
- NEVER SRC, TGT, SRC1, TGT1, SRC_n, TGT_n

**Teradata database placeholder replacement (AUTO):**

Both syntax forms appear in Lakebridge output. Replace ALL occurrences:

| Pattern found | Replace with | Notes |
|---|---|---|
| {TERA_STG_TABLE_DATABASE}.TABLE_NAME | {source_table} | Curly-brace f-string form |
| {TERA_ENT_VIEW_DATABASE}.TABLE_NAME | {source_table2} | If second source |
| {TERA_ENT_TABLE_DATABASE}.TABLE_NAME | {target_table} | Target table |
| {TERA_LGCY_VIEW_DATABASE}.TABLE_NAME | {source_table3} | Legacy view — use source_table3 to avoid collision with source_table2 |
| {TARGET_TABLE_NAME} inside SQL | {target_table} | Widget variable |
| #$TERA_STG_TABLE_DATABASE#.TABLE_NAME | {source_table} | Hash-dollar form |
| #$TERA_ENT_VIEW_DATABASE#.TABLE_NAME | {source_table2} | Hash-dollar form |
| #$TERA_LGCY_VIEW_DATABASE#.TABLE_NAME | {source_table3} | Hash-dollar form — use source_table3, not source_table2 |
| ${STG_BTCH_NO} inside SQL string | {STG_BTCH_NO} | Remove $ only |
| $'${EXTRACT_CREAT_TS}' inside SQL | '{EXTRACT_CREAT_TS}' | Remove $ only |

After replacement, ensure the replaced variable is declared in the parameters cell.
If it maps to source_table or target_table → already declared.
If it introduces a new variable → add widget declaration.

**Legacy parameter rules:**

| Parameter | Action |
|---|---|
| TERA_SERVER_NAME, TERA_*_DATABASE, TERA_*_VIEW | Remove |
| DATADIR, SUB, STAT, INST_NO | Remove |
| *PASSWD*, *_USER_ID, *_USER_WW_* | Remove + clear value |
| STG_BTCH_NO, BTCH_NO, PRCS_AUDT_NO | Keep if referenced anywhere in notebook |
| EXTRACT_CREAT_TS, JOB, TARGET_TABLE_NAME | Keep if referenced anywhere in notebook |

"Referenced anywhere" means: present in any Python expression OR present as {PARAM}
inside any f-string SQL body including spark.sql(f"""..."""). Scan the FULL notebook.

| Issue | Fix | Confidence |
|---|---|---|
| Legacy widget not referenced anywhere in notebook | Remove widget + variable | AUTO |
| Old CATALOG/SCHEMA/PREFIX style | Replace with source_*/target_* | AUTO |
| Any SRC/TGT/SRC_n/TGT_n uppercase | Replace with lowercase source_table/target_table | AUTO |
| Hardcoded "catalog.schema.table" string | Replace with f"{source_table}" | AUTO |
| Table not in 3-part UC format | Reconstruct as 3-part f-string | AUTO |

---

## GROUP I — Imports and Passthrough DataFrames

**Canonical import form — one style only:**
```python
from pyspark.sql import functions as F
from pyspark.sql.window import Window        # only if Window used
from delta.tables import DeltaTable          # only if DeltaTable used
```

| Pattern detected | Fix | Confidence |
|---|---|---|
| import pyspark.sql.functions as F | → from pyspark.sql import functions as F | AUTO |
| from pyspark.sql.functions import col, lit, ... | Remove; use F.col(), F.lit() | AUTO |
| from pyspark.sql.functions import * | Remove; replace all bare names with F. | AUTO |
| from pyspark.sql import * | Remove; replace with canonical | AUTO |
| from pyspark import SparkContext | Remove | AUTO |
| from pyspark.sql import SparkSession | Remove | AUTO |
| import os / import sys / import subprocess | Remove | AUTO |
| df_b = df_a (passthrough alias, no transformation) | Collapse — replace all df_b refs with df_a — **SKIP if df_b or df_a appears in any `.join()` or `.alias()` call downstream (join disambiguation)** | AUTO |
| col("x") without F. prefix | F.col("x") | AUTO |
| lit("x") without F. prefix | F.lit("x") | AUTO |
| when(...) without F. prefix | F.when(...) | AUTO |

---

## GROUP S — Structural Fixes

| Issue | Fix | Confidence |
|---|---|---|
| Missing # COMMAND ---------- between cells | Add separator | AUTO |
| SparkSession.builder block | Remove entirely | AUTO |
| if __name__ == "__main__": block | Remove entirely | AUTO |
| dbutils.fs.mkdirs / os.makedirs / mkdir | Remove entirely | AUTO |
| Error handler cell (dbutils.notebook.exit only) | Remove | AUTO |
| Error handler cell with business logic | Convert to try/except, keep logic | REVIEW |
| `display(df)` / `display(df.limit(n))` in a code cell | Remove — display() is interactive-only, fails silently in Databricks Jobs | AUTO |
| `display(df)` immediately after a source read or target write | Keep the `print(f"[stage] ...")` line, remove only the display() call | AUTO |

---

## GROUP SEC — Security

| Issue | Fix | Confidence |
|---|---|---|
| Hardcoded password in widget defaultValue | Clear value to '' | AUTO |
| Hardcoded password in variable assignment | Clear value to '' | AUTO |
| Hardcoded connection string with credentials | Clear credentials | AUTO |

```python
# BEFORE
dbutils.widgets.text(name='EDW_SPA_USER_WW_TERA_PASSWD', defaultValue='HDI@IJV8O9JN064IL')

# AFTER — credential cleared, secrets stub added below widget declaration:
dbutils.widgets.text(name='EDW_SPA_USER_WW_TERA_PASSWD', defaultValue='')
# BEFORE RUNNING: replace defaultValue='' with the secret:
#   dbutils.secrets.get(scope="<your-scope>", key="<your-key-name>")
# Example: dbutils.widgets.text(name='EDW_SPA_USER_WW_TERA_PASSWD',
#              defaultValue=dbutils.secrets.get(scope="kv-prod", key="edw-spa-passwd"))
# REVIEW: credential removed — configure the secret in Databricks Secrets (scope + key) before running
```

---

## GROUP L — Logic Fixes

### Broken aggregation groupBy().select() (AUTO)

Lakebridge sometimes generates:
```python
df.groupBy("col1","col2").select("col1","col2",F.sum("val").alias("total"))
```
This raises AnalysisException. Fix:
```python
df.groupBy("col1","col2").agg(F.sum("val").alias("total"))
```

### DataFrame cache and unpersist (REVIEW)

Add .cache() when a DataFrame variable is read in 3+ downstream cells.
Add .unpersist() after the last cell that reads it.

**This rule ONLY adds .cache() and .unpersist() — nothing else changes.**

```
NEVER rename the variable
NEVER merge cells
NEVER change any withColumn expression or literal value
NEVER drop columns or traceability comments
```

Detection:
1. Count cells that READ each variable as input (.filter, .select, .join, assignment from it)
2. If read count >= 3 → cache candidate
3. Find LAST WRITE cell (last assignment to that variable) → append .cache() as final method
4. Find LAST READ cell → add variableName.unpersist() # memory released immediately after

```python
# CORRECT — only .cache() added, everything else identical
lnkChanges = lnkChanges \
    .withColumn("SIEBELACCTIDERR1", expr(f"""IF(SS_SIEBEL_ACCT_ID IS NULL, '5005', IF(trim(SS_SIEBEL_ACCT_ID) = '', '5005', ''))""")) \
    .withColumn("REJECTRECORD", expr(f"""IF(SIEBELACCTIDERR1 <> '', 'Y', 'N')""")) \
    .cache()
# REVIEW: cache() added — lnkChanges read in 3+ cells — verify cluster memory

# ... cells using lnkChanges unchanged ...

lnkChanges.unpersist()  # memory released
```

Rules:
- Variable name NEVER changes
- ONE .cache() per variable on last WRITE cell
- ONE .unpersist() per variable after last READ
- If last read feeds a target write: unpersist after write + print line

### Timestamp format tokens (AUTO)

| DataStage | Spark |
|---|---|
| %hh | HH |
| %nn | mm |
| %ss | ss |
| YYYY | yyyy |

### CurrentTimestamp() unqualified (AUTO)

CurrentTimestamp() with capital C → F.current_timestamp()

### Capital-letter function names unqualified (AUTO)

| Pattern | Fix |
|---|---|
| LENGTH(col) unqualified | F.length(col) |
| SUBSTRING(col, s, n) unqualified | F.substring(col, s, n) |
| TRIM(col) unqualified | F.trim(col) |
| COALESCE(a, b) unqualified | F.coalesce(a, b) |

### lit() wrapping column name (REVIEW)

lit(COLUMN_NAME) where COLUMN_NAME is a column, not a Python variable:
```python
# BEFORE
LENGTH(coalesce(lit(LANGCDERR1) + lit(SCRNCOLNMEERR1), ''))

# AFTER
F.length(F.coalesce(F.concat(F.col("LANGCDERR1"), F.col("SCRNCOLNMEERR1")), F.lit("")))
# REVIEW: verify concat is the correct combination logic
```

### Self-referential lag/window SEQNO (REVIEW)

DataStage running counters using lag() referencing the column being computed — invalid PySpark.
```python
# BEFORE
expr(f"""IF(ERR_CD <> '', lag(IF(ERR_CD<>'', SEQNO+1, SEQNO)) over(ORDER BY DF_ROW_ID)+1, ...)""")

# AFTER
_w = Window.orderBy("DF_ROW_ID")
df = df.withColumn("ERR_FLAG", (F.col("ERR_CD") != "").cast("int")) \
       .withColumn("SEQNO", F.sum("ERR_FLAG").over(_w))
# REVIEW: SEQNO = running count of non-empty ERR_CD rows — verify matches original intent
```

---

# ════════════════════════════════════════════════════
# PART 2 — STAGE PATTERNS
# ════════════════════════════════════════════════════

## TRANSFORMER STAGE

**Detection:** `# Processing node ... type TRANSFORMER` or `# type SOURCE`
comment with `.withColumn()` chains containing DataStage BASIC expressions.

**Common Lakebridge failures:**
- BASIC functions not mapped: `Space()`, `Field()`, `Str()`, `Index()`
- `@INROWNUM` left as placeholder or missing
- `@NULL` not converted to `F.lit(None)`
- Multi-output links with conditional routing only partially generated
- `If/Then/Else` chains converted to nested `when()` with wrong precedence
- DataStage date macros (`%yyyy`, `%mm`, `Oconv`, `Iconv`) not converted
- `Not(expr)` left as DataStage syntax instead of `~(expr)`

**Fix — string function patterns:**
```python
# Space(n) — pad with spaces
F.rpad(F.lit(""), n, " ")

# Field(col, delim, n) — split and get nth token (1-based in DS)
F.split(F.col("col"), delim)[n - 1]

# Str(col, n) — left-pad to width n
F.lpad(F.col("col"), n, " ")

# Index(col, str, n) — find nth occurrence (use locate for first)
F.locate("search_str", F.col("col"))

# Not(expr) — logical NOT
~(expr)

# @NULL
F.lit(None)
```

**Fix — @INROWNUM (row number within group):**
```python
from pyspark.sql.window import Window
# Inspect original stage for partition key — use lit(1) if no partition
_w = Window.partitionBy("partition_key_col").orderBy(F.lit(1))
df = df.withColumn("row_num", F.row_number().over(_w))
# REVIEW: partitionBy key inferred — verify correct partition column
```

**Fix — @NUMROWS (total row count within partition):**
```python
from pyspark.sql.window import Window
_w_count = Window.partitionBy("partition_key_col")
df = df.withColumn("num_rows", F.count("*").over(_w_count))
# REVIEW: partitionBy key inferred — verify correct partition column
```

**Fix — @OUTROWNUM (global row number across all rows):**
```python
from pyspark.sql.window import Window
_w_global = Window.orderBy(F.lit(1))  # CRITICAL REVIEW: replace F.lit(1) with a real sort key
df = df.withColumn("out_row_num", F.row_number().over(_w_global))
# CRITICAL REVIEW: Window.orderBy(F.lit(1)) is NON-DETERMINISTIC — row order varies per run.
# This will produce different results on every execution. You MUST replace F.lit(1) with
# an actual stable sort column (e.g. a timestamp, sequence ID, or composite key) before
# running this in any environment. Leaving F.lit(1) will cause silent data ordering bugs.
```

**Fix — date macro conversion:**
```python
# Iconv(col, "D/MDY") → parse date string to date type
F.to_date(F.col("col"), "MM/dd/yyyy")

# Oconv(col, "D/MDY[2,2,4]") → format date to string
F.date_format(F.col("col"), "MM/dd/yyyy")

# DataStage %yyyy-%mm-%dd format tokens → Spark yyyy-MM-dd
# %yyyy → yyyy,  %mm → MM,  %dd → dd,  %hh → HH,  %nn → mm,  %ss → ss
```

**Fix — multi-output conditional routing:**
```python
# DataStage: one Transformer, two output links with different filter conditions
# Lakebridge often only generates one link — add the second
df_link1 = df.filter(F.col("flag") == "Y")
df_link2 = df.filter(F.col("flag") != "Y")
# REVIEW: filter condition inferred from stage comments — verify split logic
```

**Fix — nested IF precedence:**
```python
# BEFORE (wrong precedence from Lakebridge)
F.when(cond_a, val_a).when(cond_b, val_b).otherwise(
    F.when(cond_c, val_c).otherwise(val_d))

# AFTER (flat chain, correct precedence)
F.when(cond_a, val_a) \
 .when(cond_b, val_b) \
 .when(cond_c, val_c) \
 .otherwise(val_d)
```

---

## AGGREGATOR STAGE

**Detection:** `# type AGGREGATOR` or `.groupBy().` pattern.

**Common Lakebridge failures:**
- `F.first()` without `ignorenulls=True` — non-deterministic
- `F.last()` without `ignorenulls=True` — non-deterministic
- Running total (DataStage "Compute running totals") missing entirely
- GROUP BY key columns missing from `.agg()` select
- Single `F.sum()` inside `.groupBy()` call instead of `.agg()`
- Multiple agg functions collapsed into one wrong call

**Fix — standard aggregation:**
```python
df_agg = df.groupBy("key_col1", "key_col2").agg(
    F.sum("amount").alias("total_amount"),
    F.count("*").alias("record_count"),
    F.avg("price").alias("avg_price"),
    F.max("order_date").alias("latest_date"),
    F.min("order_date").alias("earliest_date"),
    F.first("description", ignorenulls=True).alias("first_desc"),
    F.last("description", ignorenulls=True).alias("last_desc"),
    F.countDistinct("customer_id").alias("unique_customers"),
)
```

**Fix — running total (DataStage "Compute running totals"):**
```python
from pyspark.sql.window import Window
_w_running = Window.partitionBy("group_col") \
    .orderBy("sort_col") \
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
df = df.withColumn("running_total", F.sum("amount").over(_w_running))
# REVIEW: partitionBy and orderBy inferred from stage — verify correct columns
```

**Fix — broken groupBy (sum inside groupBy args):**
```python
# BEFORE (Lakebridge error)
df.groupBy("dept", F.sum("salary"))
df.groupBy("dept").agg("SUM(salary)")

# AFTER
df.groupBy("dept").agg(F.sum("salary").alias("total_salary"))
```

---

## PIVOT STAGE

**Detection:** `# type PIVOT` or `PIVOT_COLUMNS_TO_ROWS` / `PIVOT_ROWS_TO_COLUMNS`
comment, or stub `# TODO: PIVOT`.

**Common Lakebridge failures:**
- Static pivot generated for dynamic DataStage pivot (column values at runtime)
- Unpivot (DataStage "Vertical pivot") missing or wrong
- Multiple value columns across pivot not handled
- PySpark version not detected — wrong unpivot syntax used

**Fix — rows to columns (standard pivot):**
```python
df_pivot = df.groupBy("key_col") \
    .pivot("category_col", ["CAT_A", "CAT_B", "CAT_C"]) \
    .agg(F.sum("value_col"))
# REVIEW: pivot values list inferred — specify known values for performance
# If values unknown at code time, omit the list (slower but dynamic):
# .pivot("category_col").agg(F.sum("value_col"))
```

**Fix — columns to rows (unpivot / vertical pivot):**
```python
# PySpark 3.4+ native
df_unpivot = df.unpivot(
    ids=["key_col"],
    values=["col_a", "col_b", "col_c"],
    variableColumnName="category",
    valueColumnName="value"
)

# PySpark < 3.4 (stack expression)
df_unpivot = df.selectExpr(
    "key_col",
    "stack(3, 'col_a', col_a, 'col_b', col_b, 'col_c', col_c) as (category, value)"
)
# REVIEW: column list for unpivot inferred from ErrRecIn/input schema — verify
```

---

## SCD (SLOWLY CHANGING DIMENSION) STAGE

**Detection:** `# type SCD` or `SCD_TYPE` comment, or Delta MERGE pattern
that is incomplete/missing for dimension tables.

**Common Lakebridge failures:**
- Type 1 (overwrite) generates inefficient loop-based UPDATE
- Type 2 (history) insert/expire logic missing or wrong
- Effective date defaults to `current_timestamp()` instead of business date
- `surrogate_key` generation missing
- `is_current` flag not set/reset correctly

**Fix — Type 1 SCD (overwrite current record):**
```python
from delta.tables import DeltaTable

dim = DeltaTable.forName(spark, target_table)
dim.alias("t").merge(
    df_incoming.alias("s"),
    "t.natural_key = s.natural_key"  # REVIEW: natural key inferred — verify
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()
```

**Fix — Type 2 SCD (full history):**
```python
from delta.tables import DeltaTable

NATURAL_KEYS  = ["customer_id"]       # REVIEW: verify natural key columns
HIGH_DATE     = "9999-12-31"
join_cond     = " AND ".join([f"t.{k} = s.{k}" for k in NATURAL_KEYS])

dim = DeltaTable.forName(spark, target_table)

# Step 1 — expire changed current rows
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenMatchedUpdate(
    condition="s.scd2_hash <> t.scd2_hash",
    set={
        "effective_end_date": F.current_date(),
        "is_current":         F.lit(False)
    }
).execute()

# Step 2 — insert new versions
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenNotMatchedInsert(values={
    "surrogate_key":      F.monotonically_increasing_id(),
    **{c: f"s.{c}" for c in df_incoming.columns},
    "effective_start_date": F.current_date(),
    "effective_end_date":   F.lit(HIGH_DATE),
    "is_current":           F.lit(True)
}).execute()
# REVIEW: scd2_hash must be pre-computed on SCD2 columns before merge
# REVIEW: column names (is_current, effective_start_date etc.) — verify schema
```

---

## LOOKUP STAGE

**Detection:** `# type LOOKUP` comment or `.join()` with broadcast pattern,
or unconnected lookup flat file reference.

**Common Lakebridge failures:**
- Sparse lookup (failure action = "continue with null") not handled — uses inner join, drops non-matching rows
- Unconnected lookup (flat file reference) generates broken file read
- Multiple lookup conditions partially mapped
- Broadcast hint missing on small reference tables
- Reject link (unmatched rows) not split out

**Fix — sparse lookup (left join):**
```python
# DataStage "Continue with null" → left join
df_result = df_main.join(
    F.broadcast(df_lookup),   # broadcast if lookup is small
    on=["join_key_col"],
    how="left"                # "inner" only for "Fail on no match"
)
# REVIEW: join type — use "inner" if DataStage was set to "Fail on no match"
```

**Fix — reject link (unmatched rows):**
```python
df_matched   = df_result.filter(F.col("lookup_col").isNotNull())
df_unmatched = df_result.filter(F.col("lookup_col").isNull())
# REVIEW: lookup_col is the first column from the lookup table — verify correct sentinel column
```

**Fix — unconnected lookup (flat file):**
```python
# Replace with Unity Catalog volume or already-ingested Delta table
df_lookup_ref = spark.read.format("delta").table(source_table)
# REVIEW: original flat file path — verify Delta table exists at source_table
```

**Fix — multi-condition lookup:**
```python
df_result = df_main.join(
    F.broadcast(df_lookup),
    (df_main["col_a"] == df_lookup["ref_col_a"]) &
    (df_main["col_b"] == df_lookup["ref_col_b"]),
    how="left"
)
```

---

## JOIN STAGE

**Detection:** `# type JOIN` comment or `.join()` calls with 3+ inputs,
or join key type mismatch, or duplicate columns after join.

**Common Lakebridge failures:**
- 3+ input joins converted as sequential joins losing correct join order
- DataStage "Full Outer" join missing — defaults to inner
- Join key type mismatch (string vs int) not cast before join
- Duplicate column names after join cause ambiguous reference errors
- Missing broadcast hint on small dimension tables

**Fix — multi-input join (3 sources):**
```python
# Join A + B first
df_ab = df_a.join(df_b, on="key_col", how="inner")
df_ab = df_ab.drop(df_b["key_col"])  # drop duplicate key

# Then join with C
df_final = df_ab.join(df_c, on="key_col", how="left")
# REVIEW: join order inferred from DataStage link order — verify correct sequence
```

**Fix — full outer join with coalesced key:**
```python
df_full = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="full")
df_full = df_full.withColumn(
    "key_col",
    F.coalesce(F.col("a.key_col"), F.col("b.key_col"))
)
```

**Fix — cast before join to prevent type mismatch:**
```python
df_a = df_a.withColumn("key_col", F.col("key_col").cast("string"))
df_b = df_b.withColumn("key_col", F.col("key_col").cast("string"))
df_joined = df_a.join(df_b, on="key_col", how="inner")
# REVIEW: cast to string assumed — verify correct target type for this key
```

**Fix — duplicate column dedup after join:**
```python
# After join, if both sides have same non-key column name
df_joined = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="inner")
# Reference with alias to avoid ambiguity
df_joined = df_joined.select(
    F.col("a.amount").alias("src_amount"),
    F.col("b.amount").alias("ref_amount"),
    "key_col"
)
```

---

## SORT STAGE

**Detection:** `# type SORT` comment or `.orderBy()` / `.sort()` calls.

**Common Lakebridge failures:**
- DataStage APT partition-aware sort emitted as global `orderBy()` — wrong semantics
- `NullFirst` / `NullLast` sort options not carried through — defaults to nulls last
- Sort immediately before Aggregator generates unnecessary extra shuffle
- Sort column direction (ASC/DESC) not preserved

**Fix — null-aware sort:**
```python
df_sorted = df.orderBy(
    F.col("sort_col1").asc_nulls_last(),
    F.col("sort_col2").desc_nulls_first()
)
# REVIEW: null handling (nulls_last / nulls_first) inferred — verify matches DS sort spec
```

**Fix — partition-aware sort (DataStage APT_SORT_PARTITIONED):**
```python
# DataStage sorted within each partition — use Window rather than global orderBy
from pyspark.sql.window import Window
_w = Window.partitionBy("partition_col").orderBy(F.col("sort_col").asc())
df = df.withColumn("row_rank", F.rank().over(_w))
# REVIEW: partition column inferred — verify correct partition key
```

**Fix — unnecessary sort before groupBy:**
```python
# BAD (Lakebridge often generates this — sorts then re-shuffles)
df.orderBy("key_col").groupBy("key_col").agg(F.sum("amount"))

# GOOD — groupBy already handles the shuffle, drop the orderBy
df.groupBy("key_col").agg(F.sum("amount").alias("total"))
```

---

## CHANGE_CAPTURE / CDC STAGE

**Detection:** `# type CHANGE_CAPTURE` or `# type CDC` traceability comment, or
`MISSING_HANDLER` stub with CDC node name, or incomplete if/elif chain comparing
old/new column values without a Delta MERGE.

**Common Lakebridge failures:**
- Stage emitted as MISSING_HANDLER stub entirely — no code generated
- Generated as broken if/elif comparing individual columns instead of Delta MERGE
- Delete handling missing — only inserts and updates generated
- Reject/error link (unmatched rows) not split out
- `whenNotMatchedBySourceDelete()` missing when full CDC sync is needed

**Fix — standard CDC using Delta MERGE:**
```python
# COMMAND ----------
# Source file     : {filename}
# Processing node : {link_name}
# Node type       : CHANGE_CAPTURE
from delta.tables import DeltaTable

target_dt = DeltaTable.forName(spark, target_table)
target_dt.alias("t").merge(
    df_new.alias("s"),
    "t.natural_key_col = s.natural_key_col"  # REVIEW: verify natural key column(s)
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .whenNotMatchedBySourceDelete() \
 .execute()
print(f"CDC merge complete on {target_table}")
# REVIEW: natural key column inferred from traceability — verify correct join condition
# REVIEW: whenNotMatchedBySourceDelete() requires Delta 2.0+ / DBR 11.0+ — verify runtime
# REVIEW: DataStage CDC may distinguish INSERT/UPDATE/DELETE via a change-type column —
#         if present, add whenMatchedUpdate(condition="s.chg_type = 'U'") variant
```

**Fix — CDC with explicit change-type column:**
```python
# When source contains a change_type column (I=Insert, U=Update, D=Delete)
target_dt.alias("t").merge(
    df_new.alias("s"),
    "t.natural_key_col = s.natural_key_col"
).whenMatchedUpdate(
    condition="s.change_type = 'U'",
    set={"*": "s.*"}
).whenMatchedDelete(
    condition="s.change_type = 'D'"
).whenNotMatchedInsert(
    condition="s.change_type = 'I'",
    values={"*": "s.*"}
).execute()
# REVIEW: change_type column name and values (I/U/D vs INSERT/UPDATE/DELETE) —
#         check original DataStage CDC stage configuration
```

**Fix — CDC reject link:**
```python
# Split unmatched / error records if CDC has a reject output link
df_rejected = df_new.filter(F.col("change_type").isNull() | ~F.col("change_type").isin("I", "U", "D"))
# REVIEW: reject condition inferred — verify sentinel value for unrecognised change types
```

---

## FUNNEL / UNION STAGE

**Detection:** `# type FUNNEL` traceability comment, or multiple DataFrames
being concatenated, or `unionAll(` / `union(` calls.

**Common Lakebridge failures:**
- `union()` used instead of `unionByName()` — column-order sensitive, breaks if schemas differ
- Schema mismatch across inputs not handled — raises AnalysisException
- DataStage FUNNEL with "Sort" option emits extra `orderBy()` after union — unnecessary shuffle
- More than 2 inputs chained with repeated `.union()` calls — correct but verbose

**Fix — standard FUNNEL (2 inputs):**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : FUNNEL
df_result = df_a.unionByName(df_b, allowMissingColumns=True)
print(f"[FUNNEL] count={df_result.count()}")
# REVIEW: allowMissingColumns=True fills missing columns with null —
#         verify all inputs have compatible column types for shared columns
```

**Fix — FUNNEL with 3+ inputs:**
```python
from functools import reduce
from pyspark.sql import DataFrame

dfs = [df_a, df_b, df_c]  # REVIEW: list all input DataFrames in DataStage link order
df_result = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), dfs)
print(f"[FUNNEL] count={df_result.count()}")
```

**Fix — remove sort after FUNNEL (unnecessary):**
```python
# If Lakebridge emits .orderBy() immediately after union — drop it
# DataStage FUNNEL sort is a partition sort, not a global sort
# REVIEW: if downstream stage explicitly requires sorted input, keep orderBy with correct key
```

---

## REMOVE_DUPLICATES / DEDUP STAGE

**Detection:** `# type REMOVE_DUPLICATES` or `# type DEDUP` traceability comment,
or `.dropDuplicates(` / `.distinct()` calls that are missing or incorrect.

**Common Lakebridge failures:**
- Key columns list empty — generates `df.distinct()` which deduplicates on ALL columns
- DataStage "Keep first" / "Keep last" selection not preserved — Spark has no built-in keep-last
- Duplicate detection across sorted groups not handled correctly
- Reject link (duplicate rows) not split out

**Fix — key-based deduplication (keep first occurrence):**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : REMOVE_DUPLICATES
df_dedup = df.dropDuplicates(["key_col1", "key_col2"])
print(f"[DEDUP] before={df.count()} after={df_dedup.count()}")
# REVIEW: key columns inferred from traceability — verify correct dedup key
```

**Fix — keep last occurrence (DataStage "Keep last"):**
```python
from pyspark.sql.window import Window
_w = Window.partitionBy("key_col1", "key_col2").orderBy(F.col("sort_col").desc())
df_ranked = df.withColumn("_rn", F.row_number().over(_w))
df_dedup   = df_ranked.filter(F.col("_rn") == 1).drop("_rn")
# REVIEW: sort_col for "keep last" inferred — verify which column determines recency
```

**Fix — split duplicate rows to reject link:**
```python
df_keys    = df.groupBy("key_col1", "key_col2").agg(F.count("*").alias("_cnt"))
df_dups    = df_keys.filter(F.col("_cnt") > 1)
df_dedup   = df.join(df_dups, on=["key_col1", "key_col2"], how="left_anti")
df_rejected = df.join(df_dups, on=["key_col1", "key_col2"], how="inner")
# REVIEW: verify key columns match REMOVE_DUPLICATES stage configuration
```

---

## MISSING_HANDLER STUBS

**Detection:** Any of these patterns anywhere in a notebook cell:
- `MISSING_HANDLER = "..."` variable assignment
- `# TODO: MISSING_HANDLER` comment
- `pass  # MISSING_HANDLER` stub
- Cell body consisting only of `pass` with a MISSING_HANDLER traceability comment above

**Fix procedure — always REVIEW confidence:**

1. Read the `# Node type` value in the traceability block of the same cell.
2. Match the node type to a section in this file and apply that fix pattern.
3. If no traceability block is present, check the surrounding cells for context clues
   (DataFrame names, column names, join keys) to infer the stage type.

| Node type found | Apply section |
|---|---|
| `PIVOT` | PIVOT STAGE section |
| `SCD` | SCD section |
| `CHANGE_CAPTURE` / `CDC` | CHANGE_CAPTURE / CDC STAGE section |
| `FUNNEL` | FUNNEL / UNION STAGE section |
| `REMOVE_DUPLICATES` / `DEDUP` | REMOVE_DUPLICATES / DEDUP STAGE section |
| `AGGREGATOR` | AGGREGATOR STAGE section |
| `JOIN` | JOIN STAGE section |
| `LOOKUP` | LOOKUP STAGE section |
| `SORT` | SORT STAGE section |
| `TRANSFORMER` | TRANSFORMER STAGE section |
| Not determinable | Keep stub, add: `# REVIEW: MISSING_HANDLER — stage type unknown, manual conversion required` |

**Output format for every resolved MISSING_HANDLER:**
```python
# COMMAND ----------
# Source file     : {filename}
# Processing node : {link_name}
# Node type       : {resolved_stage_type}
# Original DS name: {ds_name}
# Input link(s)   : {links}  |  Output link(s): {links}  |  Reject link(s): {links}
{converted PySpark code}
# REVIEW: MISSING_HANDLER resolved as {stage_type} — verify conversion matches original DataStage logic
```

---

# ════════════════════════════════════════════════════
# PART 3 — EXPRESSION MAP
# ════════════════════════════════════════════════════

## STRING FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Trim(col)` | `F.trim(F.col("col"))` | both sides |
| `LTrim(col)` | `F.ltrim(F.col("col"))` | leading only |
| `RTrim(col)` | `F.rtrim(F.col("col"))` | trailing only |
| `Strip(col,"leading")` | `F.ltrim(F.col("col"))` | |
| `Strip(col,"trailing")` | `F.rtrim(F.col("col"))` | |
| `Len(col)` | `F.length(F.col("col"))` | |
| `Length(col)` | `F.length(F.col("col"))` | alias of Len |
| `Space(n)` | `F.rpad(F.lit(""), n, " ")` | n spaces |
| `Str(col, n)` | `F.lpad(F.col("col"), n, " ")` | left-pad to width |
| `Upcase(col)` | `F.upper(F.col("col"))` | |
| `Downcase(col)` | `F.lower(F.col("col"))` | |
| `Left(col, n)` | `F.col("col").substr(1, n)` | |
| `Right(col, n)` | `F.expr(f"right(col, {n})")` | |
| `Mid(col, s, n)` | `F.col("col").substr(s, n)` | s is 1-based |
| `Field(col, delim, n)` | `F.split(F.col("col"), delim)[n-1]` | n is 1-based in DS |
| `Index(col, str, n)` | `F.locate(str, F.col("col"), n)` | n = occurrence |
| `Convert(col, from, to)` | `F.regexp_replace(F.col("col"), from, to)` | |
| `LJustify(col, n)` | `F.rpad(F.col("col"), n, " ")` | |
| `RJustify(col, n)` | `F.lpad(F.col("col"), n, " ")` | |
| `Squote(col)` | `F.concat(F.lit("'"), F.col("col"), F.lit("'"))` | |
| `Dquote(col)` | `F.concat(F.lit('"'), F.col("col"), F.lit('"'))` | |
| `col1 : col2` | `F.concat(F.col("col1"), F.col("col2"))` | DS concat op |
| `col1 \|\| col2` | `F.concat(F.col("col1"), F.col("col2"))` | |

---

## NUMERIC FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Abs(col)` | `F.abs(F.col("col"))` | |
| `Int(col)` | `F.col("col").cast("long")` | truncate toward zero (cast drops decimal, floor does not for negatives) |
| `Round(col, n)` | `F.round(F.col("col"), n)` | |
| `Mod(a, b)` | `F.col("a") % F.col("b")` | |
| `Sqrt(col)` | `F.sqrt(F.col("col"))` | |
| `Num(col)` | `F.col("col").cast("double")` | string → number |
| `IntToString(col)` | `F.col("col").cast("string")` | |
| `StringToInteger(col)` | `F.col("col").cast("integer")` | |
| `StringToDecimal(col)` | `F.col("col").cast("double")` | |
| `DecimalToString(col)` | `F.col("col").cast("string")` | |

---

## DATE & TIMESTAMP FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `Iconv(col, "D/MDY")` | `F.to_date(F.col("col"), "MM/dd/yyyy")` | parse string → date |
| `Iconv(col, "D/YMD")` | `F.to_date(F.col("col"), "yyyy-MM-dd")` | |
| `Oconv(col, "D/MDY[2,2,4]")` | `F.date_format(F.col("col"), "MM/dd/yyyy")` | format date → string |
| `Oconv(col, "D/YMD[4,2,2]")` | `F.date_format(F.col("col"), "yyyy-MM-dd")` | |
| `DateToString(col, fmt)` | `F.date_format(F.col("col"), fmt)` | |
| `StringToDate(col, fmt)` | `F.to_date(F.col("col"), fmt)` | |
| `StringToTimestamp(col, fmt)` | `F.to_timestamp(F.col("col"), fmt)` | |
| `TimeStampToDate(col)` | `F.to_date(F.col("col"))` | |
| `SecondsToTime(col)` | `F.from_unixtime(F.col("col"))` | |
| `Age(col)` | `F.datediff(F.current_date(), F.col("col"))` | days since date |
| `DaysSince(col)` | `F.datediff(F.current_date(), F.col("col"))` | alias |
| `Today()` | `F.current_date()` | |
| `Now()` | `F.current_timestamp()` | |
| `CurrentTimestamp()` | `F.current_timestamp()` | capital-C DS variant |

**DataStage date format token → Spark format token:**

| DataStage | Spark | Meaning |
|---|---|---|
| `%yyyy` | `yyyy` | 4-digit year |
| `%yy` | `yy` | 2-digit year |
| `%mm` | `MM` | month (01–12) |
| `%dd` | `dd` | day (01–31) |
| `%hh` | `HH` | hour 24h (00–23) |
| `%nn` | `mm` | minutes (00–59) |
| `%ss` | `ss` | seconds (00–59) |

---

## NULL & CONDITIONAL FUNCTIONS

| DataStage BASIC | PySpark | Notes |
|---|---|---|
| `IsNull(col)` | `F.col("col").isNull()` | |
| `IsNotNull(col)` | `F.col("col").isNotNull()` | |
| `NVL(col, val)` | `F.coalesce(F.col("col"), F.lit(val))` | |
| `NullToEmpty(col)` | `F.coalesce(F.col("col"), F.lit(""))` | |
| `NullToZero(col)` | `F.coalesce(F.col("col"), F.lit(0))` | |
| `IF(c, t, f)` | `F.when(c, t).otherwise(f)` | Python context |
| `IF(c, t, f)` | `CASE WHEN c THEN t ELSE f END` | SQL context |
| `Not(expr)` | `~(expr)` | logical NOT |
| `@NULL` | `F.lit(None)` | null literal |
| `@TRUE` | `F.lit(True)` | |
| `@FALSE` | `F.lit(False)` | |

---

## ROW & PARTITION VARIABLES

| DataStage Variable | PySpark | Notes |
|---|---|---|
| `@INROWNUM` | `F.row_number().over(Window.partitionBy(...).orderBy(F.lit(1)))` | row number within partition |
| `@NUMROWS` | `F.count("*").over(Window.partitionBy(...))` | total rows in partition |
| `@OUTROWNUM` | `F.row_number().over(Window.orderBy(F.lit(1)))` | global row number |

For all `@` row variables — always add:
```python
# REVIEW: Window partition/order columns inferred — verify correct keys
```

---

## OPERATORS

| DataStage | PySpark (Python context) | PySpark (SQL context) |
|---|---|---|
| `<>` | `!=` | keep as `<>` — valid ANSI SQL |
| `And` | `&` with parentheses | `AND` |
| `Or` | `\|` with parentheses | `OR` |
| `:` (concat) | `F.concat(...)` | `concat(...)` |
| `\|\|` (concat) | `F.concat(...)` | `concat(...)` or `\|\|` |

---

## DETECTION PATTERNS

Scan for these strings to know when to apply this map:

**Capitalised function names** (NameError at runtime):
`Trim(`, `LTrim(`, `RTrim(`, `Strip(`, `Upcase(`, `Downcase(`, `Left(`,
`Right(`, `Mid(`, `Field(`, `Index(`, `Convert(`, `LJustify(`, `RJustify(`,
`Space(`, `Str(`, `Len(`, `Length(`, `Abs(`, `Int(`, `Round(`, `Mod(`,
`Sqrt(`, `Num(`, `Iconv(`, `Oconv(`, `Age(`, `DaysSince(`, `Today(`,
`Now(`, `CurrentTimestamp(`, `IsNull(`, `IsNotNull(`, `NVL(`, `NullToEmpty(`,
`NullToZero(`, `Not(`

**@ variables** (SyntaxError or NameError):
`@INROWNUM`, `@NUMROWS`, `@OUTROWNUM`, `@NULL`, `@TRUE`, `@FALSE`

**Date format tokens** (wrong output):
`%yyyy`, `%mm`, `%dd`, `%hh`, `%nn`, `%ss`, `D/MDY`, `D/YMD`

**Concat operators in Python context** (SyntaxError):
`col1 : col2`, `col1 || col2` (when outside a spark.sql string)
