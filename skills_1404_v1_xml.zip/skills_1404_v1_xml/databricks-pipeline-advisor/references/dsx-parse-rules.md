# DSX Parse Rules — DataStage XML Reconciliation
# Version: 2026-04-14
# Loaded in Step 0-A only — when input contains a <DSExport> XML file.
# Covers all 22 DataStage processing stage types.

---

## SECTION 1 — Detection and Input Patterns

A DSX file is present when input contains one or more files with `<DSExport>` as the root element
(`.dsx` or `.xml` extension, or content starting with `<DSExport`).

If detected: run Step 0-A before all notebook indexing. Store extracted data as dsx_profile.

### Three supported input patterns

**Pattern A — Paired files (one DSX per notebook):**
User pastes multiple `.py` + `.xml` pairs, e.g. `step1.py` + `step1.xml`, `step2.py` + `step2.xml`.
Each XML file contains exactly one `<Record Type="JobDefn">` and maps to its paired notebook.

Detection: multiple `<DSExport>` files present in input.

Mapping rule: match by filename stem first — `step1.xml` maps to `step1.py` (case-insensitive stem comparison).
If stem match fails, fall back to content matching (Section 5).

**Pattern B — Single multi-job DSX (one XML contains all jobs):**
User pastes N notebooks + one `.xml` file that contains multiple `<Record Type="JobDefn">` blocks.
All jobs are exported into a single DSX file.

Detection: one `<DSExport>` file AND multiple `<Record Type="JobDefn">` blocks inside it.

Mapping rule: content matching only — use `# Original DS name: {stage_name}` in traceability blocks
to map each stage to the correct notebook (Section 5).

**Pattern C — Single job DSX (original pattern):**
User pastes N notebooks + one `.xml` file with exactly one `<Record Type="JobDefn">`.

Detection: one `<DSExport>` file AND exactly one `<Record Type="JobDefn">`.

Mapping rule: content matching — `# Original DS name: {stage_name}` across all notebooks.

---

**Processing rule for all patterns:**
Iterate over every `<Record Type="JobDefn">` found across all DSX files.
Extract stages and parameters per job (Sections 4A–4V).
Store all extracted stages in dsx_profile, tagged with their `job_name`.

---

## SECTION 2 — Decoding (apply before extracting any value)

Two layers of encoding appear in DSX properties. Both must be decoded.

### 2A. XML Entity Decoding

Apply to every property value before use:

| Entity    | Decoded character |
|-----------|-------------------|
| `&apos;`  | `'`               |
| `&lt;`    | `<`               |
| `&gt;`    | `>`               |
| `&amp;`   | `&`               |
| `&quot;`  | `"`               |

### 2B. Escape Sequence Decoding

Apply to multi-value list properties (`key`, `dropvalue`, `groupKey`, `sortKey`, etc.):

| Sequence | Meaning                                   |
|----------|-------------------------------------------|
| `\(1)`   | Record separator — between list entries   |
| `\(2)`   | Field separator — within an entry         |
| `\(3)`   | Property name marker                      |
| `\(20)`  | Empty / null                              |

**Extraction algorithm for list-type properties:**
1. Split raw value on `\(1)\(3){property_name}\(2)` — one segment per entry
2. Discard first segment (header — always starts with `\(2)\(2)0`)
3. Per remaining segment: column name = text up to next `\(2)` (before trailing `\(2)0`)
4. Collect all names as a list

**Real example** — CDC `dropvalue` property value:
```
\(2)\(2)0\(1)\(3)dropvalue\(2)DATA_VALD_BGN_TS\(2)0\(1)\(3)dropvalue\(2)CREAT_TS\(2)0
```
Split on `\(1)\(3)dropvalue\(2)` → segments after header: `DATA_VALD_BGN_TS\(2)0`, `CREAT_TS\(2)0`
Extract up to `\(2)` → `DATA_VALD_BGN_TS`, `CREAT_TS`

---

## SECTION 3 — Stage Type Identification Map

| XML pattern | DataStage stage type | PySpark equivalent |
|---|---|---|
| `<Record Type="JobDefn">` | Job definition | — parameters and job name |
| `StageType=PxChangeCapture` | Change Capture | CDC — detect insert/update/delete |
| `StageType=PxAggregator` or `CGroupBy` | Aggregator | `.groupBy().agg()` |
| `Type="TransformerStage"` or `StageType=CTransformerStage` | Transformer | `.withColumn()` chains + stage variables |
| `StageType=PxLookup` | Lookup | `LEFT JOIN` reference |
| `StageType=PxJoin` | Join | `.join()` inner/left/right/full |
| `StageType=PxFilter` | Filter | `.filter()` / `.where()` |
| `StageType=PxFunnel` | Funnel | `union()` / `unionAll()` |
| `StageType=PxSort` | Sort | `.orderBy()` |
| `StageType=PxChecksum` | Checksum | `F.md5(F.concat_ws(...))` |
| `StageType=PxSwitch` | Switch | Conditional routing — multiple `.filter()` outputs |
| `StageType=PxMerge` | Merge | `JOIN` with update/insert logic |
| `StageType=PxDifference` | Difference | `.subtract()` or anti-join |
| `StageType=PxModify` | Modify | Column rename / drop / reorder |
| `StageType=PxColumnExport` | Column Export | `F.concat_ws(delimiter, cols...)` |
| `StageType=PxColumnImport` | Column Import | `F.split(col, delimiter)` element extraction |
| `StageType=PxPivot` | Pivot | `.groupBy().pivot().agg()` |
| `StageType=PxRemDup` | Remove Duplicates | `.dropDuplicates()` |
| `StageType=PxSurrogateKeyGenerator` | Surrogate Key Generator | `row_number()` + max lookup |
| `StageType=PxCopy` | Copy | DataFrame replication to multiple outputs |
| `StageType=PxPeek` | Peek | Row logging — remove in production |
| `StageType=PxRowGenerator` | Row Generator | Test data — flag for removal |
| `StageType=PxTail` | Tail | `.orderBy(desc).limit(n)` |
| `StageType=PxSequentialFile` | Sequential File | Source/target file — handled by Group R |
| `StageType=TeradataConnectorPX` | Teradata Connector | Source/target table — handled by Group R/N |

---

## SECTION 4 — Per-Stage Extraction Rules

### 4A. Job Parameters

From `<Record Type="JobDefn">` → `<Collection Name="Parameters" Type="Parameters">`:
- Each `<SubRecord>`: name (`<Property Name="Name">`), default (`<Property Name="Default">`),
  type (`<Property Name="ParamType">`: 0=string, 1=password)
- Collect all **non-password** parameters as expected widget declarations

### 4B. PxChangeCapture (CDC)

For each `<Record Type="CustomStage">` where `<Property Name="StageType">PxChangeCapture`:

| Extract | XML source | Notes |
|---|---|---|
| `stage_name` | `<Property Name="Name">` | |
| `key_columns` | `<Property Name="key">` | escape decoder, split on `\(1)\(3)key\(2)` |
| `exempt_columns` | `<Property Name="dropvalue">` | escape decoder; if absent or `\(20)` only → `[]` |
| `selection` | `<Property Name="selection">` | `allvalues` or `changedvalues` |

### 4C. PxAggregator / CGroupBy

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `group_key_columns` | `<Property Name="groupKey">` — escape decoder |
| `aggregate_expressions` | Output pin column `<Property Name="Derivation">` values — XML entity decode |

### 4D. TransformerStage — Column Derivations

For each `<Record Type="TransformerStage">` or `Type="CustomStage"` where `StageType=CTransformerStage`:

Per output pin (`<Record Type="TrxOutput">`):
- `link_name` ← `<Property Name="Name">`
- `constraint` ← `<Property Name="Constraint">` — decode XML entities; empty string = no constraint
- `reject` ← `<Property Name="Reject">` — 0 = data output, 1 = reject link

Per output column in `<Collection Name="Columns" Type="OutputColumn">`:
- `col_name` ← `<Property Name="Name">`
- `derivation` ← `<Property Name="ParsedDerivation">` if present, else `<Property Name="Derivation">`
  — decode XML entities; strip leading `\(20)` if present
- A derivation of the form `LinkName.ColumnName` (simple passthrough) is not a gap — skip

### 4E. TransformerStage — Stage Variables (CRITICAL)

Within the same Transformer record: `<Collection Name="StageVars" Type="StageVar">`

Per `<SubRecord>`:

| Extract | XML source | Notes |
|---|---|---|
| `var_name` | `<Property Name="Name">` | |
| `expression` | `ParsedExpression` else `Expression` | decode XML entities; strip leading `\(20)` |
| `initial_value` | `<Property Name="InitialValue">` | **if present → STATEFUL variable** |
| `depends_on_vars` | `<Property Name="StageVars">` | semicolon-separated names |
| `sql_type` | `<Property Name="SqlType">` | 12=string, 3=decimal, 1=char |

**Stage variable categories:**
- **Stateless** (no `InitialValue`): recomputed fresh per row → maps to `.withColumn()`
- **Stateful** (has `InitialValue`): persists value across rows within a partition →
  requires Window function or `mapPartitions`; Lakebridge commonly generates wrong PySpark

**Real example from `wwspax46_Step03_CDC.xml`:**
- `SPANOERR1` — `If IsNull(lnkChanges.SS_SPA_NO) Then '5005' Else ...` — **stateless**
- `DLRACCTNOERR1`, `DLRLOCCDERR1`, `ADJIDERR1` — similar validation flags — **stateless**
- `REJECTRECORD` — `If (SPANOERR1 <> '' Or ...) Then 'Y' Else 'N'`, `InitialValue='N'` — **STATEFUL**

### 4F. PxLookup

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `lookup_fail` | `<Property Name="LookupFail">` on the reference input pin — `reject` or `fail` |
| Reference pin | Identified by `<Property Name="LinkType">2` |

### 4G. PxJoin

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `join_type` | MetaBag property `join_type` — `inner`, `left outer`, `right outer`, `full outer` |
| `key_columns` | `<Property Name="key">` — escape decoder |

### 4H. PxFilter

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `constraint` | `<Property Name="Constraint">` on stage output pin — decode XML entities |

### 4I. PxFunnel

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `input_pin_count` | Count of `\|` separators + 1 in `<Property Name="InputPins">` |
| `funnel_type` | MetaBag `funnel_type` — `sorted` or `unsorted` |

### 4J. PxSort

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `sort_keys` | `<Property Name="sortKey">` — escape decoder; direction suffix `A`=ascending, `D`=descending |

### 4K. PxChecksum

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `checksum_columns` | Output column `Derivation` values referencing input columns |
| `algorithm` | MetaBag checksum algorithm property — default `md5` if absent |

### 4L. PxSwitch

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| Per output pin: `output_name`, `condition` | `<Property Name="Constraint">` — decode XML entities |

### 4M. PxMerge

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `key_columns` | `<Property Name="key">` — escape decoder |
| `merge_type` | MetaBag merge type property |

### 4N. PxDifference

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `key_columns` | `<Property Name="key">` — escape decoder |

### 4O. PxModify

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| Per output column: `col_name`, `derivation` | `col_name` = renamed target; `derivation` = source column name or empty if dropped |

### 4P. PxColumnExport

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `delimiter` | MetaBag or Properties delimiter property |
| `source_columns` | Input column list in order (link column definitions) |
| `target_column` | Output column name |

### 4Q. PxColumnImport

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `delimiter` | MetaBag or Properties delimiter property |
| `source_column` | Input column containing the delimited string |
| `target_columns` | Output column list in order |

### 4R. PxPivot

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `pivot_key` | MetaBag pivot key column property |
| `pivot_values` | MetaBag pivot value list property |
| `aggregate_column` | MetaBag aggregate column property |
| `aggregate_function` | MetaBag aggregate function property |

### 4S. PxRemDup

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `key_columns` | `<Property Name="key">` — escape decoder |
| `keep_first` | MetaBag retain property — first or last |

### 4T. PxSurrogateKeyGenerator

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `key_column` | Output column where `<Property Name="KeyPosition">` > 0 |
| `start_value` | MetaBag start value property |
| `increment` | MetaBag increment property |

### 4U. PxCopy

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `output_pin_count` | Count of `\|` separators + 1 in `<Property Name="OutputPins">` |

### 4V. PxPeek / PxRowGenerator / PxTail

| Extract | XML source |
|---|---|
| `stage_name` | `<Property Name="Name">` |
| `tail_n` (PxTail only) | MetaBag tail count property |

---

## SECTION 5 — Job-to-Notebook Mapping

Apply the mapping algorithm that matches the detected input pattern (Section 1).

### Step 1 — Filename stem match (Pattern A only)

For each DSX file in the input:
1. Extract the filename stem (e.g. `step1` from `step1.xml`)
2. Search pasted notebook filenames for a case-insensitive stem match (e.g. `step1.py`)
3. If match found → assign HIGH confidence, all stages from that DSX map to that notebook
4. If no match → fall through to Step 2 (content match) for that DSX file

### Step 2 — Content match (all patterns, fallback for Pattern A)

For each `stage_name` not yet mapped by Step 1:
1. Search all pasted notebook content for `# Original DS name: {stage_name}` in traceability blocks
2. If found (exact) → HIGH confidence
3. If found (case-insensitive only) → MEDIUM confidence
4. If not found in any notebook → LOW confidence → mark as UNMATCHED

### Recording results

Record as: `{notebook_filename: [stage_names_mapped_to_it]}` with confidence per stage.

Unmatched stages → note as `UNMATCHED` in the DSX GAP REPORT.
Do not generate a fix for unmatched stages — cannot locate the cell.

### Multi-job DSX note

When one DSX contains multiple `<Record Type="JobDefn">` blocks: each job's stages are extracted
and mapped independently via content match. D-PARAM gap checks are per-job: each job's non-password
parameters must appear as widgets in the notebooks mapped to that job.

---

## SECTION 6 — Gap Detection Rules

Apply each rule against the matched notebook cell after entity and escape decoding.
All gaps are REVIEW confidence — engineer must verify before production.

| Gap ID | Stage type | Trigger condition | Severity |
|---|---|---|---|
| D-CDC-EXEMPT | PxChangeCapture | `exempt_columns` non-empty AND none of those column names appear in a filter/exclusion context in the CDC cell | HIGH |
| D-CDC-KEY | PxChangeCapture | `key_columns` from DSX absent from the change detection join or comparison columns in CDC cell | HIGH |
| D-AGG-KEY | PxAggregator | One or more `group_key_columns` missing from `.groupBy()` arguments | HIGH |
| D-AGG-EXPR | PxAggregator | DSX aggregate expressions not represented in `.agg()` call | HIGH |
| D-TRANSFORM-CONSTRAINT | TransformerStage | Output pin `constraint` non-empty AND no `.filter()` or routing on that output link | HIGH |
| D-TRANSFORM-DERIVATION | TransformerStage | Column `derivation` is non-trivial BASIC (not `Link.Col` passthrough) AND BASIC function names still present in the notebook cell | HIGH |
| D-STAGEVAR-MISSING | TransformerStage | Stage variable `var_name` absent (no `.withColumn("{var_name}", ...)` in the transformer cell) | HIGH |
| D-STAGEVAR-EXPR | TransformerStage | Stage variable present but its `.withColumn()` expression still contains unconverted BASIC function names | HIGH |
| D-STAGEVAR-STATEFUL | TransformerStage | Stage variable has `InitialValue` AND the notebook uses simple `.withColumn()` without a Window function | CRITICAL |
| D-FILTER | PxFilter | DSX filter `constraint` not present as `.filter()` / `.where()` in notebook | HIGH |
| D-LOOKUP-FAIL | PxLookup | `lookup_fail=reject` AND no reject-path handling in notebook | MEDIUM |
| D-JOIN-TYPE | PxJoin | DSX `join_type` does not match `.join(..., how=...)` argument | HIGH |
| D-SORT-KEY | PxSort | DSX sort keys or directions differ from `.orderBy()` arguments | MEDIUM |
| D-CHECKSUM | PxChecksum | Checksum columns or algorithm differ from DSX | MEDIUM |
| D-SWITCH | PxSwitch | One or more DSX output pin conditions absent from notebook routing | HIGH |
| D-MERGE | PxMerge | Merge key columns or merge logic incomplete vs DSX | HIGH |
| D-DIFFERENCE | PxDifference | Set difference key columns differ from DSX | MEDIUM |
| D-MODIFY | PxModify | Column rename / drop / reorder differs from DSX output column spec | MEDIUM |
| D-COL-EXPORT | PxColumnExport | Delimiter, column list, or column order differs from DSX | MEDIUM |
| D-COL-IMPORT | PxColumnImport | Delimiter or target column mapping differs from DSX | MEDIUM |
| D-PIVOT | PxPivot | Pivot key, values, or aggregate function differ from DSX | HIGH |
| D-REMDUP | PxRemDup | Dedup key columns differ from DSX | HIGH |
| D-SURROGATE | PxSurrogateKeyGenerator | `start_value` or `increment` differ from DSX | MEDIUM |
| D-FUNNEL-COUNT | PxFunnel | `union()` input count ≠ DSX input pin count | HIGH |
| D-COPY-COUNT | PxCopy | DataFrame not replicated to the expected number of outputs | MEDIUM |
| D-PEEK | PxPeek | Stage present in DSX — debug logging, must be removed before production | LOW |
| D-ROWGEN | PxRowGenerator | Stage present in DSX — test data generator, must not exist in production | MEDIUM |
| D-TAIL | PxTail | Tail size `n` differs from DSX or not implemented as `.orderBy(desc).limit(n)` | LOW |
| D-PARAM | JobDefn | Non-password DSX parameter has no `dbutils.widgets.text()` in any notebook | MEDIUM |

---

## SECTION 7 — Fix Patch Templates

**Constraints — apply to every patch:**
- Always use the actual DataFrame variable name from the notebook traceability block — never hardcode
- Always use `F.` prefix for all PySpark functions
- New cell patches (D-CDC-EXEMPT, D-TRANSFORM-CONSTRAINT, D-STAGEVAR-STATEFUL, D-SWITCH):
  inject as new `# COMMAND ----------` block at the correct position
- All other patches: inline `# REVIEW:` comment in the relevant existing cell
- Never rename DataFrame variables or move traceability block comments

---

### D-CDC-EXEMPT — new cell before target write

```python
# COMMAND ----------
# DSX EXEMPT COLUMNS — PxChangeCapture "dropvalue", stage: {stage_name}
# Rows where ONLY these columns changed → NO CHANGE in DataStage (not treated as an update).
# Key columns    : {comma-separated key_columns}
# Exempt columns : {comma-separated exempt_columns}
#
# REVIEW: implement exempt-column filtering before the target write below.
# Example — adjust column prefix conventions to match your CDC cell:
#   _exempt = [{quoted list of exempt col names}]
#   _key    = [{quoted list of key col names}]
#   _compare_cols = [c for c in {df_var}.columns if c not in _exempt + _key]
#   {df_var} = {df_var}.filter(
#       F.exists(F.array(*[F.col(f"before_{c}") != F.col(f"after_{c}") for c in _compare_cols]),
#                lambda x: x))
# REVIEW: verify column prefix conventions and exempt column list before running
```

### D-CDC-KEY — inline comment

```python
# REVIEW: DSX CDC key columns: {comma-separated list} — verify these are the join/comparison keys above.
```

### D-AGG-KEY / D-AGG-EXPR — inline comment

```python
# REVIEW: DSX aggregator "{stage_name}" group keys: {list} — verify .groupBy() is complete
# REVIEW: DSX aggregate expressions: {list} — verify .agg() is complete
```

### D-TRANSFORM-CONSTRAINT — new cell

```python
# COMMAND ----------
# REVIEW: DSX transformer output "{link_name}" routing constraint: {constraint_expression}
# Verify a .filter() implementing this condition routes rows to the "{link_name}" output.
```

### D-TRANSFORM-DERIVATION — inline comment

```python
# REVIEW: DSX derivation for {col_name}: {expression}
# Verify the .withColumn() above correctly converts this BASIC expression to PySpark.
```

### D-STAGEVAR-MISSING — inline comment in transformer cell

```python
# REVIEW: DSX stage variable "{var_name}" missing from this cell.
# Expected: .withColumn("{var_name}", {converted_expression})
# DSX expression (BASIC): {expression}
```

### D-STAGEVAR-EXPR — inline comment on the .withColumn()

```python
# REVIEW: Stage variable "{var_name}" may contain unconverted BASIC expression.
# DSX expression: {expression}
```

### D-STAGEVAR-STATEFUL — new cell (CRITICAL)

```python
# COMMAND ----------
# CRITICAL REVIEW: STATEFUL stage variable "{var_name}" — stage: "{stage_name}"
# InitialValue = {initial_value}  |  Depends on: {depends_on_vars}
# DSX expression: {expression}
#
# This variable RETAINS ITS VALUE ACROSS ROWS in DataStage (row-stateful).
# A simple .withColumn() recomputes per row — it does NOT replicate this behavior.
# Lakebridge likely generated incorrect PySpark for this variable.
#
# Common fix patterns:
#   Running flag / accumulator → Window function with cumulative sum
#   Carry-forward (previous row value) → F.lag() over ordered Window
#   Complex row state → consider mapPartitions (preserves partition-level state)
#
# REVIEW: identify the correct stateful pattern and implement before running in production.
# Incorrect implementation will produce WRONG RESULTS SILENTLY.
```

### D-FILTER — inline comment

```python
# REVIEW: DSX filter "{stage_name}" constraint: {constraint}
# Verify .filter() / .where() above implements this exact condition.
```

### D-LOOKUP-FAIL — inline comment

```python
# REVIEW: DSX lookup "{stage_name}" LookupFail=reject — verify reject-path handling exists below.
```

### D-JOIN-TYPE — inline comment

```python
# REVIEW: DSX join type is "{join_type}" — verify .join(..., how="{normalized_how}") above matches.
```

### D-SORT-KEY — inline comment

```python
# REVIEW: DSX sort "{stage_name}" keys: {list with ASC/DESC directions} — verify .orderBy() above matches.
```

### D-CHECKSUM — inline comment

```python
# REVIEW: DSX checksum "{stage_name}" — columns: {list}, algorithm: {algorithm}
# Verify F.md5(F.concat_ws(...)) above uses the correct columns in the correct order.
```

### D-SWITCH — new cell per missing output condition

```python
# COMMAND ----------
# REVIEW: DSX switch "{stage_name}" output "{output_name}" routing condition: {condition}
# Verify a .filter() implementing this condition exists for the "{output_name}" output link.
```

### D-MERGE — inline comment

```python
# REVIEW: DSX merge "{stage_name}" key columns: {list} — verify merge/update logic above is complete.
```

### D-DIFFERENCE — inline comment

```python
# REVIEW: DSX difference "{stage_name}" keys: {list}
# Verify .subtract() or anti-join above uses the correct key columns.
```

### D-MODIFY — inline comment

```python
# REVIEW: DSX modify "{stage_name}" expected output columns: {list with rename/drop annotations}
# Verify column renames, drops, and reordering above match DSX.
```

### D-COL-EXPORT — inline comment

```python
# REVIEW: DSX ColumnExport "{stage_name}" — delimiter: "{delimiter}", columns in order: {list}
# Verify F.concat_ws() above uses the correct delimiter and column order.
```

### D-COL-IMPORT — inline comment

```python
# REVIEW: DSX ColumnImport "{stage_name}" — delimiter: "{delimiter}", target columns in order: {list}
# Verify F.split() and element extraction above match DSX column order.
```

### D-PIVOT — inline comment

```python
# REVIEW: DSX pivot "{stage_name}" — key: {pivot_key}, values: {list}, agg: {agg_function}({agg_col})
# Verify .groupBy().pivot().agg() above matches DSX configuration.
```

### D-REMDUP — inline comment

```python
# REVIEW: DSX RemDup "{stage_name}" key columns: {list}
# Verify .dropDuplicates() above uses the correct key columns.
```

### D-SURROGATE — inline comment

```python
# REVIEW: DSX SurrogateKeyGenerator "{stage_name}" — key: {key_column}, start: {start_value}, increment: {increment}
# Verify key generation logic above matches these values.
```

### D-FUNNEL-COUNT — inline comment

```python
# REVIEW: DSX funnel "{stage_name}" has {n} input links — verify union() / unionAll() above includes all {n}.
```

### D-COPY-COUNT — inline comment

```python
# REVIEW: DSX copy "{stage_name}" replicates to {n} outputs — verify {df_var} is used in {n} downstream paths.
```

### D-PEEK — inline comment

```python
# REVIEW: DSX PxPeek stage "{stage_name}" is debug row logging — remove or comment out before production.
```

### D-ROWGEN — inline comment

```python
# REVIEW: DSX PxRowGenerator stage "{stage_name}" generates test data.
# This stage should NOT exist in a production pipeline. Verify whether this cell should be replaced with a real source read.
```

### D-TAIL — inline comment

```python
# REVIEW: DSX PxTail stage "{stage_name}" returns last {n} rows.
# Verify implementation above uses .orderBy(desc).limit({n}) or equivalent.
```

### D-PARAM — inline comment in parameters cell

```python
# REVIEW: DSX parameter "{param_name}" (default="{default_value}") — verify widget declaration exists above.
```
