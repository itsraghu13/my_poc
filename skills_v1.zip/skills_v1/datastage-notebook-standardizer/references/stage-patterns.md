# Stage Patterns — DataStage Notebook Standardizer
# Read when notebook contains TRANSFORMER, AGGREGATOR, PIVOT, SCD,
# LOOKUP, JOIN, or SORT stage comments, or relevant PySpark patterns.

---

## TRANSFORMER STAGE

**Detection:** `# Processing node ... type TRANSFORMER` or `# type SOURCE`
comment with `.withColumn()` chains containing DataStage BASIC expressions.

**Common Lakebridge failures:**
- BASIC functions not mapped: `Space()`, `Field()`, `Str()`, `Index()`
- `@INROWNUM` left as placeholder or missing
- `@NULL` not converted to `F.lit(None)`
- Multi-output links with conditional routing only partially generated
- `If/Then/Else` chains converted to nested `when()` with wrong precedence
- DataStage date macros (`%yyyy`, `%mm`, `Oconv`, `Iconv`) not converted
- `Not(expr)` left as DataStage syntax instead of `~(expr)`

**Fix — string function patterns:**
```python
# Space(n) — pad with spaces
F.rpad(F.lit(""), n, " ")

# Field(col, delim, n) — split and get nth token (1-based in DS)
F.split(F.col("col"), delim)[n - 1]

# Str(col, n) — left-pad to width n
F.lpad(F.col("col"), n, " ")

# Index(col, str, n) — find nth occurrence (use locate for first)
F.locate("search_str", F.col("col"))

# Not(expr) — logical NOT
~(expr)

# @NULL
F.lit(None)
```

**Fix — @INROWNUM (row number within group):**
```python
from pyspark.sql.window import Window
# Inspect original stage for partition key — use lit(1) if no partition
_w = Window.partitionBy("partition_key_col").orderBy(F.lit(1))
df = df.withColumn("row_num", F.row_number().over(_w))
# REVIEW: partitionBy key inferred — verify correct partition column
```

**Fix — @NUMROWS (total row count within partition):**
```python
from pyspark.sql.window import Window
_w_count = Window.partitionBy("partition_key_col")
df = df.withColumn("num_rows", F.count("*").over(_w_count))
# REVIEW: partitionBy key inferred — verify correct partition column
```

**Fix — @OUTROWNUM (global row number across all rows):**
```python
from pyspark.sql.window import Window
_w_global = Window.orderBy(F.lit(1))  # CRITICAL REVIEW: replace F.lit(1) with a real sort key
df = df.withColumn("out_row_num", F.row_number().over(_w_global))
# CRITICAL REVIEW: Window.orderBy(F.lit(1)) is NON-DETERMINISTIC — row order varies per run.
# This will produce different results on every execution. You MUST replace F.lit(1) with
# an actual stable sort column (e.g. a timestamp, sequence ID, or composite key) before
# running this in any environment. Leaving F.lit(1) will cause silent data ordering bugs.
```

**Fix — date macro conversion:**
```python
# Iconv(col, "D/MDY") → parse date string to date type
F.to_date(F.col("col"), "MM/dd/yyyy")

# Oconv(col, "D/MDY[2,2,4]") → format date to string
F.date_format(F.col("col"), "MM/dd/yyyy")

# DataStage %yyyy-%mm-%dd format tokens → Spark yyyy-MM-dd
# %yyyy → yyyy,  %mm → MM,  %dd → dd,  %hh → HH,  %nn → mm,  %ss → ss
```

**Fix — multi-output conditional routing:**
```python
# DataStage: one Transformer, two output links with different filter conditions
# Lakebridge often only generates one link — add the second
df_link1 = df.filter(F.col("flag") == "Y")
df_link2 = df.filter(F.col("flag") != "Y")
# REVIEW: filter condition inferred from stage comments — verify split logic
```

**Fix — nested IF precedence:**
```python
# BEFORE (wrong precedence from Lakebridge)
F.when(cond_a, val_a).when(cond_b, val_b).otherwise(
    F.when(cond_c, val_c).otherwise(val_d))

# AFTER (flat chain, correct precedence)
F.when(cond_a, val_a) \
 .when(cond_b, val_b) \
 .when(cond_c, val_c) \
 .otherwise(val_d)
```

---

## AGGREGATOR STAGE

**Detection:** `# type AGGREGATOR` or `.groupBy().` pattern.

**Common Lakebridge failures:**
- `F.first()` without `ignorenulls=True` — non-deterministic
- `F.last()` without `ignorenulls=True` — non-deterministic
- Running total (DataStage "Compute running totals") missing entirely
- GROUP BY key columns missing from `.agg()` select
- Single `F.sum()` inside `.groupBy()` call instead of `.agg()`
- Multiple agg functions collapsed into one wrong call

**Fix — standard aggregation:**
```python
df_agg = df.groupBy("key_col1", "key_col2").agg(
    F.sum("amount").alias("total_amount"),
    F.count("*").alias("record_count"),
    F.avg("price").alias("avg_price"),
    F.max("order_date").alias("latest_date"),
    F.min("order_date").alias("earliest_date"),
    F.first("description", ignorenulls=True).alias("first_desc"),
    F.last("description", ignorenulls=True).alias("last_desc"),
    F.countDistinct("customer_id").alias("unique_customers"),
)
```

**Fix — running total (DataStage "Compute running totals"):**
```python
from pyspark.sql.window import Window
_w_running = Window.partitionBy("group_col") \
    .orderBy("sort_col") \
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
df = df.withColumn("running_total", F.sum("amount").over(_w_running))
# REVIEW: partitionBy and orderBy inferred from stage — verify correct columns
```

**Fix — broken groupBy (sum inside groupBy args):**
```python
# BEFORE (Lakebridge error)
df.groupBy("dept", F.sum("salary"))
df.groupBy("dept").agg("SUM(salary)")

# AFTER
df.groupBy("dept").agg(F.sum("salary").alias("total_salary"))
```

---

## PIVOT STAGE

**Detection:** `# type PIVOT` or `PIVOT_COLUMNS_TO_ROWS` / `PIVOT_ROWS_TO_COLUMNS`
comment, or stub `# TODO: PIVOT`.

**Common Lakebridge failures:**
- Static pivot generated for dynamic DataStage pivot (column values at runtime)
- Unpivot (DataStage "Vertical pivot") missing or wrong
- Multiple value columns across pivot not handled
- PySpark version not detected — wrong unpivot syntax used

**Fix — rows to columns (standard pivot):**
```python
df_pivot = df.groupBy("key_col") \
    .pivot("category_col", ["CAT_A", "CAT_B", "CAT_C"]) \
    .agg(F.sum("value_col"))
# REVIEW: pivot values list inferred — specify known values for performance
# If values unknown at code time, omit the list (slower but dynamic):
# .pivot("category_col").agg(F.sum("value_col"))
```

**Fix — columns to rows (unpivot / vertical pivot):**
```python
# PySpark 3.4+ native
df_unpivot = df.unpivot(
    ids=["key_col"],
    values=["col_a", "col_b", "col_c"],
    variableColumnName="category",
    valueColumnName="value"
)

# PySpark < 3.4 (stack expression)
df_unpivot = df.selectExpr(
    "key_col",
    "stack(3, 'col_a', col_a, 'col_b', col_b, 'col_c', col_c) as (category, value)"
)
# REVIEW: column list for unpivot inferred from ErrRecIn/input schema — verify
```

---

## SCD (SLOWLY CHANGING DIMENSION) STAGE

**Detection:** `# type SCD` or `SCD_TYPE` comment, or Delta MERGE pattern
that is incomplete/missing for dimension tables.

**Common Lakebridge failures:**
- Type 1 (overwrite) generates inefficient loop-based UPDATE
- Type 2 (history) insert/expire logic missing or wrong
- Effective date defaults to `current_timestamp()` instead of business date
- `surrogate_key` generation missing
- `is_current` flag not set/reset correctly

**Fix — Type 1 SCD (overwrite current record):**
```python
from delta.tables import DeltaTable

dim = DeltaTable.forName(spark, TGT_dim)
dim.alias("t").merge(
    df_incoming.alias("s"),
    "t.natural_key = s.natural_key"  # REVIEW: natural key inferred — verify
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .execute()
```

**Fix — Type 2 SCD (full history):**
```python
from delta.tables import DeltaTable

NATURAL_KEYS  = ["customer_id"]       # REVIEW: verify natural key columns
HIGH_DATE     = "9999-12-31"
join_cond     = " AND ".join([f"t.{k} = s.{k}" for k in NATURAL_KEYS])

dim = DeltaTable.forName(spark, TGT_dim)

# Step 1 — expire changed current rows
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenMatchedUpdate(
    condition="s.scd2_hash <> t.scd2_hash",
    set={
        "effective_end_date": F.current_date(),
        "is_current":         F.lit(False)
    }
).execute()

# Step 2 — insert new versions
dim.alias("t").merge(
    df_incoming.alias("s"),
    join_cond + " AND t.is_current = true"
).whenNotMatchedInsert(values={
    "surrogate_key":      F.monotonically_increasing_id(),
    **{c: f"s.{c}" for c in df_incoming.columns},
    "effective_start_date": F.current_date(),
    "effective_end_date":   F.lit(HIGH_DATE),
    "is_current":           F.lit(True)
}).execute()
# REVIEW: scd2_hash must be pre-computed on SCD2 columns before merge
# REVIEW: column names (is_current, effective_start_date etc.) — verify schema
```

---

## LOOKUP STAGE

**Detection:** `# type LOOKUP` comment or `.join()` with broadcast pattern,
or unconnected lookup flat file reference.

**Common Lakebridge failures:**
- Sparse lookup (failure action = "continue with null") not handled — uses inner join, drops non-matching rows
- Unconnected lookup (flat file reference) generates broken file read
- Multiple lookup conditions partially mapped
- Broadcast hint missing on small reference tables
- Reject link (unmatched rows) not split out

**Fix — sparse lookup (left join):**
```python
# DataStage "Continue with null" → left join
df_result = df_main.join(
    F.broadcast(df_lookup),   # broadcast if lookup is small
    on=["join_key_col"],
    how="left"                # "inner" only for "Fail on no match"
)
# REVIEW: join type — use "inner" if DataStage was set to "Fail on no match"
```

**Fix — reject link (unmatched rows):**
```python
df_matched   = df_result.filter(F.col("lookup_col").isNotNull())
df_unmatched = df_result.filter(F.col("lookup_col").isNull())
# REVIEW: lookup_col is the first column from the lookup table — verify correct sentinel column
```

**Fix — unconnected lookup (flat file):**
```python
# Replace with Unity Catalog volume or already-ingested Delta table
df_lookup_ref = spark.read.format("delta").table(SRC_reference)
# REVIEW: original flat file path — verify Delta table exists at SRC_reference
```

**Fix — multi-condition lookup:**
```python
df_result = df_main.join(
    F.broadcast(df_lookup),
    (df_main["col_a"] == df_lookup["ref_col_a"]) &
    (df_main["col_b"] == df_lookup["ref_col_b"]),
    how="left"
)
```

---

## JOIN STAGE

**Detection:** `# type JOIN` comment or `.join()` calls with 3+ inputs,
or join key type mismatch, or duplicate columns after join.

**Common Lakebridge failures:**
- 3+ input joins converted as sequential joins losing correct join order
- DataStage "Full Outer" join missing — defaults to inner
- Join key type mismatch (string vs int) not cast before join
- Duplicate column names after join cause ambiguous reference errors
- Missing broadcast hint on small dimension tables

**Fix — multi-input join (3 sources):**
```python
# Join A + B first
df_ab = df_a.join(df_b, on="key_col", how="inner")
df_ab = df_ab.drop(df_b["key_col"])  # drop duplicate key

# Then join with C
df_final = df_ab.join(df_c, on="key_col", how="left")
# REVIEW: join order inferred from DataStage link order — verify correct sequence
```

**Fix — full outer join with coalesced key:**
```python
df_full = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="full")
df_full = df_full.withColumn(
    "key_col",
    F.coalesce(F.col("a.key_col"), F.col("b.key_col"))
)
```

**Fix — cast before join to prevent type mismatch:**
```python
df_a = df_a.withColumn("key_col", F.col("key_col").cast("string"))
df_b = df_b.withColumn("key_col", F.col("key_col").cast("string"))
df_joined = df_a.join(df_b, on="key_col", how="inner")
# REVIEW: cast to string assumed — verify correct target type for this key
```

**Fix — duplicate column dedup after join:**
```python
# After join, if both sides have same non-key column name
df_joined = df_a.alias("a").join(df_b.alias("b"), on="key_col", how="inner")
# Reference with alias to avoid ambiguity
df_joined = df_joined.select(
    F.col("a.amount").alias("src_amount"),
    F.col("b.amount").alias("ref_amount"),
    "key_col"
)
```

---

## SORT STAGE

**Detection:** `# type SORT` comment or `.orderBy()` / `.sort()` calls.

**Common Lakebridge failures:**
- DataStage APT partition-aware sort emitted as global `orderBy()` — wrong semantics
- `NullFirst` / `NullLast` sort options not carried through — defaults to nulls last
- Sort immediately before Aggregator generates unnecessary extra shuffle
- Sort column direction (ASC/DESC) not preserved

**Fix — null-aware sort:**
```python
df_sorted = df.orderBy(
    F.col("sort_col1").asc_nulls_last(),
    F.col("sort_col2").desc_nulls_first()
)
# REVIEW: null handling (nulls_last / nulls_first) inferred — verify matches DS sort spec
```

**Fix — partition-aware sort (DataStage APT_SORT_PARTITIONED):**
```python
# DataStage sorted within each partition — use Window rather than global orderBy
from pyspark.sql.window import Window
_w = Window.partitionBy("partition_col").orderBy(F.col("sort_col").asc())
df = df.withColumn("row_rank", F.rank().over(_w))
# REVIEW: partition column inferred — verify correct partition key
```

**Fix — unnecessary sort before groupBy:**
```python
# BAD (Lakebridge often generates this — sorts then re-shuffles)
df.orderBy("key_col").groupBy("key_col").agg(F.sum("amount"))

# GOOD — groupBy already handles the shuffle, drop the orderBy
df.groupBy("key_col").agg(F.sum("amount").alias("total"))
```

---

## CHANGE_CAPTURE / CDC STAGE

**Detection:** `# type CHANGE_CAPTURE` or `# type CDC` traceability comment, or
`MISSING_HANDLER` stub with CDC node name, or incomplete if/elif chain comparing
old/new column values without a Delta MERGE.

**Common Lakebridge failures:**
- Stage emitted as MISSING_HANDLER stub entirely — no code generated
- Generated as broken if/elif comparing individual columns instead of Delta MERGE
- Delete handling missing — only inserts and updates generated
- Reject/error link (unmatched rows) not split out
- `whenNotMatchedBySourceDelete()` missing when full CDC sync is needed

**Fix — standard CDC using Delta MERGE:**
```python
# COMMAND ----------
# Source file     : {filename}
# Processing node : {link_name}
# Node type       : CHANGE_CAPTURE
from delta.tables import DeltaTable

target_dt = DeltaTable.forName(spark, target_table)
target_dt.alias("t").merge(
    df_new.alias("s"),
    "t.natural_key_col = s.natural_key_col"  # REVIEW: verify natural key column(s)
).whenMatchedUpdateAll() \
 .whenNotMatchedInsertAll() \
 .whenNotMatchedBySourceDelete() \
 .execute()
print(f"CDC merge complete on {target_table}")
# REVIEW: natural key column inferred from traceability — verify correct join condition
# REVIEW: whenNotMatchedBySourceDelete() requires Delta 2.0+ / DBR 11.0+ — verify runtime
# REVIEW: DataStage CDC may distinguish INSERT/UPDATE/DELETE via a change-type column —
#         if present, add whenMatchedUpdate(condition="s.chg_type = 'U'") variant
```

**Fix — CDC with explicit change-type column:**
```python
# When source contains a change_type column (I=Insert, U=Update, D=Delete)
target_dt.alias("t").merge(
    df_new.alias("s"),
    "t.natural_key_col = s.natural_key_col"
).whenMatchedUpdate(
    condition="s.change_type = 'U'",
    set={"*": "s.*"}
).whenMatchedDelete(
    condition="s.change_type = 'D'"
).whenNotMatchedInsert(
    condition="s.change_type = 'I'",
    values={"*": "s.*"}
).execute()
# REVIEW: change_type column name and values (I/U/D vs INSERT/UPDATE/DELETE) —
#         check original DataStage CDC stage configuration
```

**Fix — CDC reject link:**
```python
# Split unmatched / error records if CDC has a reject output link
df_rejected = df_new.filter(F.col("change_type").isNull() | ~F.col("change_type").isin("I", "U", "D"))
# REVIEW: reject condition inferred — verify sentinel value for unrecognised change types
```

---

## FUNNEL / UNION STAGE

**Detection:** `# type FUNNEL` traceability comment, or multiple DataFrames
being concatenated, or `unionAll(` / `union(` calls.

**Common Lakebridge failures:**
- `union()` used instead of `unionByName()` — column-order sensitive, breaks if schemas differ
- Schema mismatch across inputs not handled — raises AnalysisException
- DataStage FUNNEL with "Sort" option emits extra `orderBy()` after union — unnecessary shuffle
- More than 2 inputs chained with repeated `.union()` calls — correct but verbose

**Fix — standard FUNNEL (2 inputs):**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : FUNNEL
df_result = df_a.unionByName(df_b, allowMissingColumns=True)
print(f"[FUNNEL] count={df_result.count()}")
# REVIEW: allowMissingColumns=True fills missing columns with null —
#         verify all inputs have compatible column types for shared columns
```

**Fix — FUNNEL with 3+ inputs:**
```python
from functools import reduce
from pyspark.sql import DataFrame

dfs = [df_a, df_b, df_c]  # REVIEW: list all input DataFrames in DataStage link order
df_result = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), dfs)
print(f"[FUNNEL] count={df_result.count()}")
```

**Fix — remove sort after FUNNEL (unnecessary):**
```python
# If Lakebridge emits .orderBy() immediately after union — drop it
# DataStage FUNNEL sort is a partition sort, not a global sort
# REVIEW: if downstream stage explicitly requires sorted input, keep orderBy with correct key
```

---

## REMOVE_DUPLICATES / DEDUP STAGE

**Detection:** `# type REMOVE_DUPLICATES` or `# type DEDUP` traceability comment,
or `.dropDuplicates(` / `.distinct()` calls that are missing or incorrect.

**Common Lakebridge failures:**
- Key columns list empty — generates `df.distinct()` which deduplicates on ALL columns
- DataStage "Keep first" / "Keep last" selection not preserved — Spark has no built-in keep-last
- Duplicate detection across sorted groups not handled correctly
- Reject link (duplicate rows) not split out

**Fix — key-based deduplication (keep first occurrence):**
```python
# COMMAND ----------
# Processing node : {link_name}
# Node type       : REMOVE_DUPLICATES
df_dedup = df.dropDuplicates(["key_col1", "key_col2"])
print(f"[DEDUP] before={df.count()} after={df_dedup.count()}")
# REVIEW: key columns inferred from traceability — verify correct dedup key
```

**Fix — keep last occurrence (DataStage "Keep last"):**
```python
from pyspark.sql.window import Window
_w = Window.partitionBy("key_col1", "key_col2").orderBy(F.col("sort_col").desc())
df_ranked = df.withColumn("_rn", F.row_number().over(_w))
df_dedup   = df_ranked.filter(F.col("_rn") == 1).drop("_rn")
# REVIEW: sort_col for "keep last" inferred — verify which column determines recency
```

**Fix — split duplicate rows to reject link:**
```python
df_keys    = df.groupBy("key_col1", "key_col2").agg(F.count("*").alias("_cnt"))
df_dups    = df_keys.filter(F.col("_cnt") > 1)
df_dedup   = df.join(df_dups, on=["key_col1", "key_col2"], how="left_anti")
df_rejected = df.join(df_dups, on=["key_col1", "key_col2"], how="inner")
# REVIEW: verify key columns match REMOVE_DUPLICATES stage configuration
```

---

## MISSING_HANDLER STUBS

**Detection:** Any of these patterns anywhere in a notebook cell:
- `MISSING_HANDLER = "..."` variable assignment
- `# TODO: MISSING_HANDLER` comment
- `pass  # MISSING_HANDLER` stub
- Cell body consisting only of `pass` with a MISSING_HANDLER traceability comment above

**Fix procedure — always REVIEW confidence:**

1. Read the `# Node type` value in the traceability block of the same cell.
2. Match the node type to a section in this file and apply that fix pattern.
3. If no traceability block is present, check the surrounding cells for context clues
   (DataFrame names, column names, join keys) to infer the stage type.

| Node type found | Apply section |
|---|---|
| `PIVOT` | PIVOT STAGE section |
| `SCD` | SCD section |
| `CHANGE_CAPTURE` / `CDC` | CHANGE_CAPTURE / CDC STAGE section |
| `FUNNEL` | FUNNEL / UNION STAGE section |
| `REMOVE_DUPLICATES` / `DEDUP` | REMOVE_DUPLICATES / DEDUP STAGE section |
| `AGGREGATOR` | AGGREGATOR STAGE section |
| `JOIN` | JOIN STAGE section |
| `LOOKUP` | LOOKUP STAGE section |
| `SORT` | SORT STAGE section |
| `TRANSFORMER` | TRANSFORMER STAGE section |
| Not determinable | Keep stub, add: `# REVIEW: MISSING_HANDLER — stage type unknown, manual conversion required` |

**Output format for every resolved MISSING_HANDLER:**
```python
# COMMAND ----------
# Source file     : {filename}
# Processing node : {link_name}
# Node type       : {resolved_stage_type}
# Original DS name: {ds_name}
# Input link(s)   : {links}  |  Output link(s): {links}  |  Reject link(s): {links}
{converted PySpark code}
# REVIEW: MISSING_HANDLER resolved as {stage_type} — verify conversion matches original DataStage logic
```
