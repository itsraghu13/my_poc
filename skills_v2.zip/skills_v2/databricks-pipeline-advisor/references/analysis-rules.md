# Analysis Rules — Databricks Pipeline Advisor
# Read during STEP 1 (indexing) and STEP 2 (analysis)

---

## FILENAME PARSING RULES

DataStage-converted Lakebridge notebooks follow predictable naming patterns.
Extract metadata from the filename before reading any content.

**Common patterns:**

| Pattern | Example | Extracted fields |
|---|---|---|
| `Step{N}_{TYPE}_{DOMAIN}_{job_id}.py` | `Step03_CDC_SPA_PARTY_wwspax46.py` | seq=3, type=CDC, domain=SPA_PARTY, job=wwspax46 |
| `Step{N}_{TYPE}_{DOMAIN}.py` | `Step01_Extract_Orders.py` | seq=1, type=Extract, domain=Orders |
| `{DOMAIN}_{TYPE}_{N}.py` | `SPA_PARTY_Load_001.py` | domain=SPA_PARTY, type=Load, seq=1 |
| `{job_id}_{description}.py` | `wwspax46_cdc_party.py` | job=wwspax46 |
| No pattern | `my_notebook.py` | none — filename only |

**Sequence number extraction:**
- Leading digits: `03_...` → seq=3
- `Step03` → seq=3
- `step_03` → seq=3
- No number found → seq=None (treat as unordered)

**Type classification from filename keywords:**

| Keyword in filename | Likely type |
|---|---|
| `Extract`, `Unl`, `Unload` | Source extraction |
| `Load`, `Lod` | Target load |
| `Transform`, `Trans` | Transformation |
| `CDC`, `ChgCapture`, `Change` | Change capture |
| `Agg`, `Aggr` | Aggregation |
| `Join` | Join |
| `Ref`, `Reference` | Reference/lookup load |
| `Error`, `Err`, `Reject` | Error handling |
| `Init`, `Initialize` | Initialization |
| `Cleanup`, `Purge` | Cleanup |

---

## TRACEABILITY COMMENT EXTRACTION

Extract from `# Processing node` metadata blocks — these are the richest
source of structural information without reading actual code.

**Block format:**
```
# Processing node : {output_link_name}
# Node type       : {STAGE_TYPE}
# Column count    : {n}
# Original DS name: {stage_name}
# Input link(s)   : {link_names or NONE}
# Output link(s)  : {link_names or NONE}
# Reject link(s)  : {link_names or NONE}
```

**Stage type classification:**

| Node type value | Category | Meaning |
|---|---|---|
| `SOURCE`, `SEQUENTIAL_FILE` (read) | source | Reads data in |
| `TARGET`, `SEQUENTIAL_FILE` (write), `DB_CONNECTOR` | target | Writes data out |
| `TRANSFORMER` | transform | Applies business logic |
| `AGGREGATOR` | aggregate | Groups and aggregates |
| `JOIN` | join | Joins multiple inputs |
| `LOOKUP` | lookup | Reference join |
| `CHANGE_CAPTURE`, `CDC` | cdc | Change data capture |
| `FILTER` | filter | Row filtering |
| `SORT` | sort | Ordering |
| `FUNNEL` | union | Combines streams |
| `PIVOT` | pivot | Rows/columns transpose |
| `REMOVE_DUPLICATES` | dedup | Deduplication |
| `SURROGATE_KEY` | key_gen | Key generation |
| `SCD` | scd | Slowly changing dimension |
| `COPY` | passthrough | No transformation |

**Complexity scoring from stage types:**

| Stage type | Complexity points |
|---|---|
| SOURCE / TARGET | 1 |
| FILTER / COPY / SORT | 1 |
| TRANSFORMER / MODIFY | 2 |
| AGGREGATOR / FUNNEL | 2 |
| JOIN / LOOKUP | 3 |
| CHANGE_CAPTURE / CDC | 4 |
| SCD | 4 |
| PIVOT | 3 |

Total complexity score = sum of all stage points.
Use for merge risk assessment: high complexity notebooks are riskier to merge.

---

## SOURCE / TARGET EXTRACTION

Extract in this priority order (stop at first successful extraction):

**Priority 1 — SRC/TGT variable declarations (most reliable):**
```python
SRC  = f"{source_catalog}.{source_schema}.{source_table}"
SRC1 = f"{source_catalog}.{source_schema}.{source1_table}"
TGT  = f"{target_catalog}.{target_schema}.{target_table}"
```
Extract the f-string pattern → record as `{catalog}.{schema}.{table}` with
widget variable names as placeholders where literal values aren't available.

**Priority 2 — Old-style uppercase declarations:**
```python
SRC_orders = f"{PREFIX}.orders"
TGT_result = f"{PREFIX}.order_summary"
```

**Priority 3 — Direct spark.read / saveAsTable calls:**
```python
spark.read.format("delta").table("main.dw.orders")
df.write.format("delta").saveAsTable("main.dw.result")
```

**Priority 4 — Traceability comment node type:**
- `# Node type : SOURCE` → this cell reads data (source)
- `# Node type : TARGET` → this cell writes data (target)
- `# Original DS name: {name}` → use as table name hint if no explicit table found

**Priority 5 — Filename domain inference (lowest confidence):**
- Extract domain from filename → guess table name as `{domain}_table`
- Always mark as LOW confidence

---

## DEPENDENCY DAG RULES

**A depends on B if:**
Notebook A has a source table that matches a target table of Notebook B.

**Matching logic:**
- Exact match: `main.dw.orders` == `main.dw.orders` → definite dependency
- Schema match: `{source_catalog}.{source_schema}.orders` and
  `{target_catalog}.{target_schema}.orders` with same schema vars → likely dependency
- Name-only match: both reference `orders` table but different catalogs → possible dependency, LOW confidence

**Execution order:**
Topological sort of dependency graph.
Notebooks with no dependencies = Stage 1 (can run first, potentially in parallel).
Notebooks that only depend on Stage 1 = Stage 2. And so on.

**Cycle detection:**
Traverse dependencies using depth-first search. For each notebook, follow its dependency
chain recursively while tracking the current path. If you encounter a notebook already
present in the current path → cycle detected.
Report: `CYCLE: NotebookA → NotebookB → NotebookA` and stop attempting to order.
Cycles indicate a data modeling problem — report immediately, do not attempt to order.

---

## MERGE SIGNAL RULES

### SIGNAL 1 — Linear Chain (LOW RISK)

**Condition:**
- Notebook A writes exactly one target table T
- Notebook B reads T as its only (or primary) source
- No other notebook in the folder reads T

**Score:** Strong merge candidate
**Risk:** Low — straightforward sequential execution, no fan-out
**Suggested name:** Combine both step numbers and domains: `Step{A}_{B}_{domain}.py`
**Flag as "Keep separate" instead if:**
- Different schedule/trigger hints in filename (daily vs hourly)
- Cell count combined > 25 (too large to merge comfortably)
- One notebook has CDC or SCD stage type (complex logic, keep isolated)

### SIGNAL 2 — Parallel Siblings (MEDIUM RISK)

**Condition:**
- Notebooks A and B read the exact same source table(s)
- Neither depends on the other
- Their targets are different tables (not a conflict)

**Score:** Moderate merge candidate
**Risk:** Medium — must verify no shared mutable state, no ordering assumptions
**Benefit:** Eliminates duplicate source reads (one Delta scan instead of two)
**Suggested approach:** Merge with shared `spark.read` at top, two output paths

### SIGNAL 3 — Tiny Notebook (LOW RISK)

**Condition:**
- Notebook has ≤ 4 cells total
- Has at least one dependency (not standalone)

**Score:** Merge with upstream or downstream neighbor
**Risk:** Low — small notebooks are easy to inline
**Note:** If the tiny notebook is a reference/lookup load, keep separate

### SIGNAL 4 — Same Domain, Sequential Steps (LOW RISK)

**Condition:**
- Two notebooks share the same domain name in filename
- Sequential step numbers (e.g. Step03 and Step04 of same domain)
- No other notebook between them in execution order

**Score:** Possible merge candidate
**Risk:** Low if same stage type, medium if different stage types
**Note:** This is a weaker signal — requires content verification

---

## REDUNDANCY DETECTION RULES

### REDUNDANCY TYPE 1 — Duplicate Source Read

**Condition:** Same source table read in 2+ notebooks with no merging benefit
(they produce different targets that are both needed independently)

**Severity:** LOW — performance concern, not a correctness issue
**Suggestion:** Consider materializing shared source as a cached/persisted
intermediate table upstream, or create a view

### REDUNDANCY TYPE 2 — Duplicate Target Write (CONFLICT)

**Condition:** Same target table written by 2+ notebooks

**Severity:** HIGH — potential data corruption depending on write modes
**Always flag as CONFLICT — requires immediate engineer review**
**Check:** If one is `overwrite` and one is `append` — likely intentional pipeline
           If both are `overwrite` — one will clobber the other

### REDUNDANCY TYPE 3 — Identical Stage Logic

**Condition:** Two notebooks have the same node names in traceability comments
AND same stage type sequence AND same column count

**Severity:** MEDIUM — possible copy-paste duplication from DataStage
**Suggestion:** Verify if these are truly duplicates or handle different data partitions

---

## ORPHAN DETECTION

Two distinct categories — do not conflate:

**ORPHAN** — no metadata detectable:
- No source table detected AND no target table detected
- Cannot be placed in execution order
- Requires investigation before processing

**STANDALONE** — functional but independent:
- Source and target tables detected, but source is not produced by any other notebook
  in this folder AND target is not consumed by any other notebook in this folder
- Can be placed in execution order; simply has no internal dependencies
- Report in EXECUTION ORDER as `INDEPENDENT`

**Orphan types (applies to ORPHAN category only):**

| Type | Pattern | Action |
|---|---|---|
| True orphan | No metadata detectable | Investigate — may need content analysis |
| External source | Source table detected but originates outside this folder | Note as external dependency |
| External target | Target table detected but consumed outside this folder | Note as pipeline output |
| Standalone utility | Init, cleanup, reference load — metadata present but no DAG edges | Keep separate, note as utility |

---

## REPORT CONFIDENCE RULES

**Mark each finding with its confidence level:**

```
[HIGH]   — tables explicitly declared as SRC/TGT variables
[MEDIUM] — extracted from spark.read/saveAsTable or traceability comments  
[LOW]    — inferred from filename only
```

**Downgrade confidence when:**
- Widget variables used for table names (actual table name unknown at analysis time)
- Traceability comments missing from notebook
- File listing provided but not content

**When confidence is LOW on a merge candidate:**
- Change recommendation from `[MERGE]` to `[REVIEW BEFORE MERGE]`
- Never auto-recommend MERGE without seeing notebook content
- Add: "Verify table dependencies before merging — source/target names inferred from filename only"
- Engineer must confirm dependency before merge proceeds

---

## CONSOLIDATION DECISION RULES

Apply these rules to every merge candidate identified.
Score each factor. Final decision = MERGE only if ALL merge conditions pass.

### MERGE — all of these must be true

| Factor | Merge condition |
|---|---|
| Schedule | All notebooks run on same schedule/trigger |
| Cell count | Estimated combined total after intermediate table elimination ≤ 25 code cells (> 25 = keep separate). Apply this check AFTER estimating how many read/write pairs will be removed by the merge — e.g. a 14+14 cell merge that eliminates 4 intermediate cells becomes ~24, which passes. |
| Shared target | No two notebooks write to the same target table |
| Stage types | No CDC, no SCD, no CHANGE_CAPTURE stage present |
| Intermediate tables | No external consumers of the intermediate table are known from the provided notebooks — **engineer must independently verify no other pipelines, BI tools, or teams consume this table before merge executes** |
| Runtime | No individual stage known to take > 10 min |
| Parallelism | Notebooks do not need to run in parallel (no Stage 1 pattern) |

**Cell count definition:** Count code cells only (blocks separated by `# COMMAND ----------`).
Markdown section header cells (`%md`) do not count toward the 25-cell limit.
Estimate cell count AFTER elimination: subtract 2 cells per intermediate table removed (one write cell + one read cell).

### KEEP SEPARATE — any one of these makes it non-mergeable

| Factor | Keep separate condition |
|---|---|
| Schedule | Different schedules or triggers |
| Parallelism | Notebooks designed to run in parallel (Stage 1 extraction pattern) |
| Shared target | Multiple notebooks write to same target table (SCD/CDC pattern) |
| SCD Type 2 | Step N deactivates + Step N+1 inserts new version → strict sequence required |
| CDC present | Any CHANGE_CAPTURE or CDC stage type |
| External consumer | Engineer confirms the intermediate table is consumed by another pipeline or team outside this folder (the advisor cannot detect this — always flag as REVIEW on intermediate table merges) |
| Cell count | Combined cells > 25 |
| Team boundary | Different teams own different notebooks |
| Runtime | Any stage > 10 min individually |

### REPORT FORMAT FOR EACH CANDIDATE

```
MERGE-01 — {type}  [{MERGE | KEEP SEPARATE | REVIEW}]
  Notebooks : Step01.py + Step03.py
  Reason    : {primary reason for recommendation}

  Scoring:
  ✓ Same schedule
  ✓ Combined cells: 14 (≤ 25)
  ✓ No shared target table
  ✗ CDC stage present in Step03   ← KEEP SEPARATE (any ✗ = keep separate)

  Decision  : KEEP SEPARATE
  Because   : CDC stage — needs independent restart capability
```

When suggesting a merged notebook name:

1. Combine step numbers: `Step01` + `Step03` → `Step01_03_`
2. Keep shared domain: both are `SPA_PARTY` → `Step01_03_SPA_PARTY_`
3. Combine types if different: `Extract` + `Transform` → `Extract_Transform_`
4. Keep job ID from first notebook: `_wwspax46`

Example: `Step01_03_Extract_Transform_SPA_PARTY_wwspax46.py`

If no clear naming pattern exists: `{domain}_merged.py`

---

## WIDGET CONFLICT RESOLUTION (during merge assembly)

When two notebooks being merged declare a widget with the same name but different
`defaultValue`s, apply these rules:

**Same semantic role (both are source tables, or both are target tables):**
- First notebook (lower step number) keeps the original name: `source_table`
- Second notebook's widget is renamed: `source_table2`
- Update ALL references to the renamed widget throughout the second notebook's cells — this includes:
  - Python variable references: `source_table` → `source_table2`
  - f-string SQL bodies: `{source_table}` inside `spark.sql(f"""...""")` → `{source_table2}`
  - Any widget `.get()` call: `dbutils.widgets.get("source_table")` → `dbutils.widgets.get("source_table2")`
  - Missing any f-string SQL reference is a **silent runtime error** — the old table name stays hardcoded in the query
- Add comment: `# REVIEW: merged widget — verify correct table assignment for each stage below`

**Different semantic roles (one source, one target — same widget name):**
- This is a naming collision, not a conflict. Rename the source to `source_table`,
  target to `target_table` regardless of original names.

**Retained business parameters (STG_BTCH_NO, BTCH_NO, etc.):**
- If both notebooks have the same business parameter widget → keep one, deduplicate
- If values differ → keep first notebook's defaultValue, add REVIEW comment

**Rule: never silently drop a widget.** If in doubt, keep both with distinct names.
